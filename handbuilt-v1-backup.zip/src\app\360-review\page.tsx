import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { CallbackForm } from "@/components/Forms";
import { CtaBand, Eyebrow } from "@/components/ui";
import { PILLARS_FULL } from "@/lib/content";

export const metadata: Metadata = {
  title: "CSI360™ Financial Health Checkup | CSI Group®",
  description: "A physical for your financial life. Seven pillars, one sitting, one written plan.",
};

export default function Page() {
  return (
    <>
      <section className="on-navy bg-navy text-white section-pad">
        <div className="container-csi">
          <Image
            src="/logos/csi360_logo_with_tm__white.png"
            alt="CSI360™"
            width={240}
            height={88}
            className="mb-6 h-16 w-auto"
          />
          <h1 className="max-w-3xl text-[clamp(34px,5vw,56px)]">
            Your Financial Life. Fully Integrated.™
          </h1>
          <hr className="rule" />
          <p className="tagline text-lg">One Team | One Plan | Total Clarity</p>
          <p className="mt-5 max-w-2xl text-xl text-white/90">
            A physical for your financial life. In one sitting we review seven pillars of your
            household, put the picture in writing, and put your next steps in order.
          </p>
          <p className="mt-6 inline-block rounded-full border border-white/40 px-4 py-2 font-display text-sm font-bold">
            Already included in your CSI Member benefits
          </p>
        </div>
      </section>

      <section className="section-pad">
        <div className="container-csi">
          <Eyebrow n="01">The seven pillars</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">Every part of your financial life, in one room.</h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {PILLARS_FULL.map((p) => (
              <div key={p.num} className="card">
                <p className="eyebrow mb-2">{p.num}</p>
                <h3 className="mb-2 text-xl">{p.title}</h3>
                <p>{p.body}</p>
              </div>
            ))}
            <div className="card !bg-navy text-white">
              <h3 className="mb-2 !text-white">What you walk away with</h3>
              <ul className="checklist">
                <li>A written picture of where your household stands</li>
                <li>Prioritized next steps, in order</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-light-gray section-pad">
        <div className="container-csi grid items-center gap-10 md:grid-cols-2">
          <div>
            <Eyebrow n="02">Step zero</Eyebrow>
            <h2 className="text-[clamp(28px,3.6vw,42px)]">Start with your free Health Check.</h2>
            <p className="mt-4">
              Twenty-four questions, about five minutes, and you see your score instantly. It tells
              us, and you, where to look first.
            </p>
            <Link href="/health-check" className="btn mt-6">
              Take Your Free Health Check
            </Link>
          </div>
          <div>
            <h3 className="mb-3 text-xl">Or book your CSI360™ review</h3>
            <CallbackForm source="360-review" />
          </div>
        </div>
      </section>
      <CtaBand title="Ready for your checkup?" />
    </>
  );
}
