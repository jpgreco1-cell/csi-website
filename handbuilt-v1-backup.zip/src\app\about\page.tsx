import type { Metadata } from "next";
import { CtaBand, Eyebrow, PageHero } from "@/components/ui";
import { MILESTONES } from "@/lib/content";

export const metadata: Metadata = {
  title: "About | CSI Group®",
  description:
    "A family company, second generation, since 1973. Confidence, service, integrity.",
};

const VALUES = ["Confidence", "Service", "Integrity"];

export default function Page() {
  return (
    <>
      <PageHero
        eyebrow="About CSI Group®"
        title="A family company, second generation, since 1973."
        lead="High-quality tax, financial, insurance and estate planning, made accessible to everyday families, not just the wealthy."
      />

      <section className="section-pad">
        <div className="container-csi grid gap-12 lg:grid-cols-[1.4fr_1fr]">
          <div className="space-y-5 text-lg leading-relaxed">
            <Eyebrow n="01">It started on a side street in Brooklyn</Eyebrow>
            <p>
              CSI Group&apos;s story began in 1973, when Peter Greco opened a small tax practice on a
              side street in Brooklyn, New York. For the immigrant community he served, taxes,
              insurance and financial paperwork were often overwhelming. Affluent communities had
              access to this kind of help. Middle-class families were largely left on their own.
              Peter changed that, becoming a trusted resource and advocate for hardworking families
              who needed clarity and support.
            </p>
            <p>
              By 1983, word of Peter&apos;s value to the community had spread, and he opened a
              state-of-the-art office on 86th Street in Bensonhurst. It quickly became the go-to
              destination for financial help in the neighborhood. Through the 1980s he grew the team
              and the services, always guided by what his clients were worried about that year.
            </p>
            <p>
              In 1990, CSI expanded to New Jersey with its first location in Matawan, and the work
              shifted from immigrant families to suburban, middle-class households. The mission did
              not change: high-quality tax, financial, insurance and estate planning made accessible
              to everyday families, not just the wealthy.
            </p>
            <p>
              When Peter passed away, his sons James and Robert Greco took the helm as co-CEOs,
              honoring their father&apos;s legacy while building the firm of the future. Through
              CSI360™, a household now receives tax, investment, retirement, insurance and estate
              planning as one integrated plan, coordinated by a single lead advisor who holds the big
              picture. Today the firm is 20 branches and more than 80 professionals and growing, with
              every client still treated like family, exactly as Peter intended more than 50 years
              ago.
            </p>
          </div>
          <aside className="space-y-6">
            <div className="card">
              <p className="eyebrow mb-2">Co-CEOs</p>
              <p className="font-title text-2xl font-bold text-navy">James Greco</p>
              <p className="font-title text-2xl font-bold text-navy">Robert Greco</p>
            </div>
            <blockquote className="card text-[19px] italic">
              &ldquo;Financial services have long been fragmented and reserved for the
              ultra-wealthy. We are changing that by bringing everything under one roof and
              delivering it with the high-touch experience our clients deserve.&rdquo;
              <footer className="mt-3 font-display text-sm font-bold not-italic text-navy">
                James Greco, Co-CEO
              </footer>
            </blockquote>
          </aside>
        </div>
      </section>

      <section className="on-navy bg-navy text-white section-pad">
        <div className="container-csi">
          <Eyebrow>What we stand for</Eyebrow>
          <div className="mt-4 grid gap-6 md:grid-cols-3">
            {VALUES.map((v) => (
              <p
                key={v}
                className="rounded-xl border border-white/20 border-t-[3px] border-t-light-blue bg-white/5 p-6 font-title text-3xl font-bold"
              >
                {v}
              </p>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-light-gray section-pad">
        <div className="container-csi">
          <Eyebrow n="02">Our timeline</Eyebrow>
          <ol className="mt-8 grid gap-6 md:grid-cols-5">
            {MILESTONES.map((m) => (
              <li key={m.year} className="card">
                <p className="font-title text-2xl font-bold text-navy">{m.year}</p>
                <h3 className="mt-1 mb-2 text-base">{m.title}</h3>
                <p className="text-[15px]">{m.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>
      <CtaBand title="Meet the family that will guide yours." />
    </>
  );
}
