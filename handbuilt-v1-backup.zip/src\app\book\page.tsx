import type { Metadata } from "next";
import { BookCall } from "@/components/BookCall";

export const metadata: Metadata = {
  title: "Book Your Intro Call | CSI Group®",
  description: "Your first conversation is Complimentary & Commitment-Free! Pick a branch, a day and a time.",
};

export default function Page() {
  return <BookCall />;
}
