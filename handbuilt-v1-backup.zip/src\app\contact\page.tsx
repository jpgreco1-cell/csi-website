import type { Metadata } from "next";
import Link from "next/link";
import { CallbackForm } from "@/components/Forms";
import { PageHero } from "@/components/ui";
import { EMAIL, PHONE, PHONE_TEL } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contact | CSI Group®",
  description: "One call reaches your whole financial world. Tell us where you stand and we will call you back.",
};

export default function Page() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="One call reaches your whole financial world."
        lead="Tell us where you stand. We will call you back, usually the same business day."
      />
      <section className="section-pad">
        <div className="container-csi grid gap-12 md:grid-cols-2">
          <div className="space-y-6">
            <div className="card">
              <p className="eyebrow mb-2">Call</p>
              <a href={PHONE_TEL} className="font-display text-3xl font-bold">
                {PHONE}
              </a>
              <p className="mt-3 text-[15px]">
                General line: <a href="tel:+17322243990">(732) 224-3990</a>
                <br />
                Email: <a href={`mailto:${EMAIL}`}>{EMAIL}</a>
                <br />
                Selling your practice: <a href="mailto:joinus@csicpa.com">joinus@csicpa.com</a>
              </p>
            </div>
            <div className="card">
              <p className="eyebrow mb-2">Headquarters</p>
              <p>
                1599 NJ-34
                <br />
                Wall Township, NJ 07727
              </p>
              <p className="mt-3 font-display text-sm font-bold">
                <Link href="/locations">All 20 branches →</Link>
              </p>
            </div>
            <p className="tagline">
              Complimentary &amp; Commitment-Free! First conversations cost nothing. If we are not the
              right fit, we will tell you that too.
            </p>
          </div>
          <CallbackForm source="contact" />
        </div>
      </section>
    </>
  );
}
