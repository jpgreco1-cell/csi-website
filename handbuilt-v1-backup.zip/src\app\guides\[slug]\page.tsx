import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHero } from "@/components/ui";
import { POSTS } from "@/lib/more-content";

// Only posts with a written body get a page. See POSTS in more-content.ts.
const LIVE = POSTS.filter((p) => p.body.length > 0);

export function generateStaticParams() {
  // Next requires at least one entry for a static dynamic route.
  return LIVE.length ? LIVE.map((p) => ({ slug: p.slug })) : [{ slug: "_" }];
}

export async function generateMetadata({ params }: PageProps<"/guides/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const p = LIVE.find((x) => x.slug === slug);
  return p ? { title: `${p.title} | CSI Group®`, description: p.dek } : {};
}

export default async function Page({ params }: PageProps<"/guides/[slug]">) {
  const { slug } = await params;
  const p = LIVE.find((x) => x.slug === slug);
  if (!p) notFound();

  return (
    <>
      <PageHero eyebrow={p.kicker} title={p.title} lead={p.dek} />
      <article className="section-pad">
        <div className="mx-auto w-full max-w-[720px] space-y-5 px-6 text-lg leading-relaxed">
          <p className="font-display text-sm font-bold text-navy">By the CSI Group team</p>
          {p.body.map((para, i) => (
            <p key={i}>{para}</p>
          ))}
          <p className="font-display text-[11px] leading-snug text-disclosure">
            This article is educational and is not individualized financial, tax, legal, or
            investment advice.
          </p>
          <Link href="/book" className="btn">
            Book Intro Call
          </Link>
        </div>
      </article>
    </>
  );
}
