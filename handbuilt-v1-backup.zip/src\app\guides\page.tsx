import type { Metadata } from "next";
import Link from "next/link";
import { GenericForm } from "@/components/GenericForm";
import { NewsletterForm } from "@/components/Forms";
import { CtaBand, Eyebrow, PageHero } from "@/components/ui";
import { POSTS } from "@/lib/more-content";

export const metadata: Metadata = {
  title: "Guides & Blog | CSI Group®",
  description: "Plain answers, written by our team, to the questions members ask most.",
};

export default function Page() {
  return (
    <>
      <PageHero
        eyebrow="Guides"
        title="Plain answers, written by our team."
        lead="Free guides and articles on the questions members ask most, answered without the jargon."
      />

      <section className="section-pad">
        <div className="container-csi grid gap-10 lg:grid-cols-2">
          <div>
            <Eyebrow n="01">Free e-guide</Eyebrow>
            <h2 className="text-[clamp(28px,3.6vw,42px)]">Estate Planning Guide</h2>
            <p className="mt-4">
              What every household needs in writing, in plain language. Tell us where to send it
              and the guide arrives in your inbox. Free of charge, and nothing is ever sold to
              anyone.
            </p>
            <p className="mt-4 text-sm text-disclosure">
              More guides on taxes, retirement income and insurance are on the way. The newsletter
              tells you when each one is ready.
            </p>
          </div>
          {/* TODO: the guide email is not sent yet. Wire delivery of the PDF before launch. */}
          <GenericForm
            source="guide-estate-planning"
            extra={{ guide: "Estate Planning Guide" }}
            fields={[
              { name: "firstName", label: "First name", required: true, autoComplete: "given-name" },
              { name: "email", label: "Email", type: "email", required: true, autoComplete: "email" },
            ]}
            submit="Email me the guide"
            success="Your request is in. If the guide does not arrive in a few minutes, check your spam folder or call 1-800-TAX-LAWS® and we will send it again."
          />
        </div>
      </section>

      <section className="bg-light-gray section-pad">
        <div className="container-csi">
          <Eyebrow n="02">From the blog</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(28px,3.6vw,42px)]">Short reads from our advisors.</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {POSTS.map((p) => {
              const live = p.body.length > 0;
              const inner = (
                <>
                  <p className="eyebrow mb-2">{p.kicker}</p>
                  <h3 className="mb-2 text-xl">{p.title}</h3>
                  <p>{p.dek}</p>
                  <p className="mt-4 font-display text-sm font-bold text-mid-blue">
                    {live ? "Read the article →" : "Coming soon"}
                  </p>
                </>
              );
              return live ? (
                <Link key={p.slug} href={`/guides/${p.slug}`} className="card block !text-ink">
                  {inner}
                </Link>
              ) : (
                <article key={p.slug} className="card">
                  {inner}
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section id="newsletter" className="on-navy scroll-mt-24 bg-navy text-white section-pad">
        <div className="container-csi grid items-center gap-8 md:grid-cols-2">
          <div>
            <h2 className="text-[clamp(28px,3.6vw,42px)]">What families should be doing this season.</h2>
            <p className="mt-3 text-white/90">
              A short free newsletter from our team. Free of charge, and you can leave any time.
            </p>
          </div>
          <NewsletterForm />
        </div>
      </section>

      <section className="section-pad">
        <div className="container-csi grid gap-10 md:grid-cols-2">
          <div>
            <Eyebrow n="03">Ask our team</Eyebrow>
            <h2 className="text-[clamp(28px,3.6vw,42px)]">A question we have not answered?</h2>
            <p className="mt-4">Send it over. Our team reads every one.</p>
          </div>
          <GenericForm
            source="guides-ask"
            consent
            fields={[
              { name: "name", label: "Your name", required: true, autoComplete: "name" },
              { name: "email", label: "Email", type: "email", required: true, autoComplete: "email" },
              { name: "phone", label: "Phone (optional)", type: "tel", autoComplete: "tel" },
              { name: "question", label: "Your question", type: "textarea", required: true },
            ]}
            submit="Send my question"
            success="We got your question and will be in touch."
          />
        </div>
      </section>
      <CtaBand title="Prefer to talk it through?" />
    </>
  );
}
