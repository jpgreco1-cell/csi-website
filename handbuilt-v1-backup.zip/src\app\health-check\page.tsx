import type { Metadata } from "next";
import { HealthCheck } from "@/components/HealthCheck";

export const metadata: Metadata = {
  title: "Free Financial Health Check | CSI Group®",
  description: "Answer 24 quick questions and get your free Financial Health Score in about five minutes.",
};

export default function Page() {
  return <HealthCheck />;
}
