import type { Metadata } from "next";
import Link from "next/link";
import { GenericForm } from "@/components/GenericForm";
import { Eyebrow, PageHero } from "@/components/ui";
import { CAREER_FITS, CAREER_REASONS, CAREER_STATS, ROLES } from "@/lib/more-content";

export const metadata: Metadata = {
  title: "Join Our Team | CSI Group®",
  description: "Careers here are measured in decades, not quarters. See open roles at CSI Group.",
};

export default function Page() {
  return (
    <>
      <PageHero
        eyebrow="Join our team"
        title="Everyone says financial services is broken. We are the ones rebuilding it."
        lead="Tax, financial, insurance and estate work, coordinated under one roof, priced for the households the industry has ignored for 50 years. That is the whole company, and it needs people who care about it."
      >
        <p className="tagline mt-5 text-lg">Careers here are measured in decades, not quarters.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a href="#roles" className="btn">
            See open roles
          </a>
          <Link href="/about" className="btn btn-outline">
            Read our story
          </Link>
        </div>
      </PageHero>

      <section className="bg-light-gray py-10">
        <dl className="container-csi grid grid-cols-2 gap-6 text-center md:grid-cols-4">
          {CAREER_STATS.map((s) => (
            <div key={s.label}>
              <dt className="sr-only">{s.label}</dt>
              <dd className="font-title text-4xl font-bold text-navy">{s.value}</dd>
              <p className="font-display text-sm font-semibold text-mid-blue" aria-hidden>
                {s.label}
              </p>
            </div>
          ))}
        </dl>
      </section>

      <section className="section-pad">
        <div className="container-csi">
          <Eyebrow n="01">Why people stay</Eyebrow>
          <p className="max-w-3xl text-lg">
            Most firms hire you to push volume through a season. We hire you to know families. That
            difference shows up in your calendar, your career path, and the work you are proud of in
            April.
          </p>
          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {CAREER_REASONS.map((r) => (
              <div key={r.title} className="card">
                <h3 className="mb-2 text-lg">{r.title}</h3>
                <p className="text-[15px]">{r.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="on-navy bg-navy text-white section-pad">
        <div className="container-csi max-w-3xl">
          <h2 className="text-[clamp(28px,3.6vw,42px)]">You are one of us if…</h2>
          <ul className="checklist mt-6 text-lg">
            {CAREER_FITS.map((f) => (
              <li key={f}>{f}</li>
            ))}
          </ul>
        </div>
      </section>

      <section id="roles" className="scroll-mt-24 section-pad">
        <div className="container-csi">
          <Eyebrow n="02">Open roles</Eyebrow>
          <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {ROLES.map((r) => (
              <article key={r.title} className="card">
                <h3 className="mb-1 text-lg">{r.title}</h3>
                <p className="mb-3 font-display text-xs font-bold uppercase tracking-wider text-mid-blue">
                  {r.where}
                </p>
                <p className="text-[15px]">{r.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="apply" className="scroll-mt-24 bg-light-gray section-pad">
        <div className="container-csi grid gap-10 md:grid-cols-2">
          <div>
            <Eyebrow n="03">Apply</Eyebrow>
            <h2 className="text-[clamp(28px,3.6vw,42px)]">Tell us about you.</h2>
            <p className="mt-4">
              We read every application. You can also email{" "}
              <a href="mailto:joinus@csicpa.com">joinus@csicpa.com</a>.
            </p>
            {/* TODO: add resume upload once file storage is chosen. */}
          </div>
          <GenericForm
            source="careers-apply"
            consent
            fields={[
              { name: "name", label: "Full name", required: true, autoComplete: "name" },
              { name: "email", label: "Email", type: "email", required: true, autoComplete: "email" },
              { name: "phone", label: "Phone", type: "tel", required: true, autoComplete: "tel" },
              {
                name: "role",
                label: "Role you are interested in",
                type: "select",
                required: true,
                options: [...ROLES.map((r) => r.title), "Something else"],
              },
              { name: "message", label: "Tell us a little about yourself", type: "textarea" },
            ]}
            submit="Send my application"
            success="We have your application and will be in touch."
          />
        </div>
      </section>
    </>
  );
}
