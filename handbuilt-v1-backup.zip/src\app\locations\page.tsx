import type { Metadata } from "next";
import { Eyebrow, PageHero } from "@/components/ui";
import { MatchForm } from "@/components/MatchForm";
import { BRANCHES } from "@/lib/content";

export const metadata: Metadata = {
  title: "Locations | CSI Group®",
  description: "20 branches: 18 in New Jersey and 2 in New York. Find the one nearest you.",
};

export default function Page() {
  const hq = BRANCHES.find((b) => b.hq)!;
  return (
    <>
      <PageHero
        eyebrow="Locations"
        title="20 branches. 18 in New Jersey, 2 in New York."
        lead="Find the branch nearest you, or tell us where you are and we will match you."
      />

      <section className="section-pad">
        <div className="container-csi">
          <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
            {/* TODO: replace with an interactive map once a provider is chosen. */}
            <div
              role="img"
              aria-label="Map placeholder"
              className="flex min-h-[260px] items-center justify-center rounded-xl border-2 border-dashed border-navy/25 bg-light-gray p-6 text-center font-display text-sm font-semibold text-disclosure"
            >
              [Map placeholder: all 20 branches across New Jersey and New York]
            </div>
            <div className="card !bg-navy text-white">
              <p className="eyebrow mb-2 !text-sky-blue">Headquarters</p>
              <h2 className="!font-display !text-2xl !text-white">{hq.town}</h2>
              <p className="mt-3 text-white/90">{hq.address}</p>
              <p className="mt-2">
                <a href={`tel:${hq.phone.replace(/-/g, "")}`} className="!text-white">
                  {hq.phone}
                </a>
              </p>
            </div>
          </div>

          <div className="mt-14">
            <Eyebrow n="01">Every branch</Eyebrow>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {BRANCHES.map((b) => (
                <article key={b.town} className="card">
                  <h3 className="mb-1 text-lg">{b.town}</h3>
                  <p className="text-[15px]">{b.address}</p>
                  <p className="mt-2 font-display text-sm font-bold">
                    <a href={`tel:${b.phone.replace(/-/g, "")}`}>{b.phone}</a>
                  </p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-light-gray section-pad">
        <div className="container-csi grid items-start gap-10 md:grid-cols-2">
          <div>
            <Eyebrow n="02">Not sure which one?</Eyebrow>
            <h2 className="text-[clamp(28px,3.6vw,42px)]">Match me to a branch.</h2>
            <p className="mt-4">
              Tell us your town or ZIP code and we will call you with the nearest branch and the
              earliest time we can meet.
            </p>
          </div>
          <MatchForm />
        </div>
      </section>
    </>
  );
}
