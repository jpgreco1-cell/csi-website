import type { Metadata } from "next";
import { CallbackForm } from "@/components/Forms";
import { PageHero } from "@/components/ui";

export const metadata: Metadata = {
  title: "Member Login | CSI Group®",
  description: "Sign in to your CSI Group member portal.",
};

// TODO: confirm the live portal address. The design prototype shows portal.csicpa.com.
const PORTAL_URL = "https://portal.csicpa.com";

export default function Page() {
  return (
    <>
      <PageHero eyebrow="Member login" title="Welcome back." lead="Sign in to your member portal." />
      <section className="section-pad">
        <div className="container-csi grid gap-12 md:grid-cols-2">
          <div className="space-y-5">
            {/* The portal handles credentials, so this site never collects passwords. */}
            <a href={PORTAL_URL} className="btn" rel="noopener">
              Sign in to my portal
            </a>
            <p className="text-[15px]">
              Forgot your password? Call 1-800-TAX-LAWS® and we will reset it with you on the line.
            </p>
            <div className="card">
              <p className="eyebrow mb-2">Inside your member portal</p>
              <p>
                Your whole financial life, in one place you can open any time. Every account, your
                Financial Health Score, your tax return, your will, and your CSI360™ Team, one
                sign-in away.
              </p>
            </div>
          </div>
          <div>
            <h2 className="mb-2 text-2xl">Not a member yet?</h2>
            <p className="mb-4">
              Membership starts the moment your household uses one of our services. Leave your
              number and a lead advisor will call.
            </p>
            <CallbackForm source="member-login" />
          </div>
        </div>
      </section>
    </>
  );
}
