import type { Metadata } from "next";
import { CallbackForm } from "@/components/Forms";
import { CtaBand, Eyebrow, PageHero } from "@/components/ui";
import { BENEFITS, ONBOARDING } from "@/lib/content";

export const metadata: Metadata = {
  title: "Membership | CSI Group®",
  description:
    "Clients here are members. One number to call, a lead advisor who remembers, and your team assigned up front.",
};

export default function Page() {
  return (
    <>
      <PageHero
        eyebrow="Membership"
        title="What you get as a member."
        lead="Use any one CSI service and you are a member. The rest of the firm is already waiting for you."
        aside={<CallbackForm compact source="membership-hero" />}
      />

      <section className="section-pad">
        <div className="container-csi">
          <Eyebrow n="01">How membership begins</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">Four steps, and you are home.</h2>
          <ol className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {ONBOARDING.map((s) => (
              <li key={s.n} className="card">
                <p className="font-title text-4xl font-bold text-light-blue">{s.n}</p>
                <h3 className="mt-2 mb-2 text-lg">{s.title}</h3>
                <p className="text-[15px]">{s.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="bg-light-gray section-pad">
        <div className="container-csi">
          <Eyebrow n="02">Friction removed</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">Six things members stop worrying about.</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {BENEFITS.map((b) => (
              <div key={b.title} className="card">
                <h3 className="mb-2 text-lg">{b.title}</h3>
                <p>{b.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <CtaBand title="One conversation is all it takes to begin." text="Complimentary & Commitment-Free!" />
    </>
  );
}
