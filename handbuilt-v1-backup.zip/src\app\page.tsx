import Image from "next/image";
import Link from "next/link";
import { CallbackForm } from "@/components/Forms";
import { PHONE, PHONE_TEL } from "@/lib/site";

const PILLARS = [
  "Cash Flow & Debt",
  "Retirement Income",
  "Tax Strategy",
  "Investments",
  "Insurance & Risk",
  "Estate & Legacy",
  "Family & Next Generation",
];

const CHIPS = [
  { t: "That IRS letter.", href: "/services/tax" },
  { t: "The 401(k) from two jobs ago.", href: "/services/wealth" },
  { t: "Mom's estate.", href: "/services/estate" },
  { t: "The will you have been meaning to write.", href: "/services/estate" },
  { t: "The tax bill that made no sense.", href: "/services/tax" },
  { t: "A policy nobody has looked at in ten years.", href: "/services/insurance" },
];

const TEAM = [
  ["Tax", "CPA or IRS Enrolled Agent"],
  ["Financial", "Registered Investment Advisor or CFP®, fiduciary"],
  ["Estate", "Attorney"],
  ["Insurance", "Licensed insurance specialist"],
  ["Service", "Client Service"],
];

const STAGES = [
  ["20s", "Start strong"],
  ["30s", "Build and protect"],
  ["40s", "Grow with the family"],
  ["50s", "Aim at retirement"],
  ["70s+", "Keep it in order"],
];

const TOWNS = [
  "Bedminster", "Brick", "Califon", "East Windsor", "Ewing", "Freehold", "Hillsborough",
  "Kendall Park", "Manahawkin", "Matawan", "Mountain Lakes", "Mountainside", "Red Bank",
  "Sicklerville", "Wall Township", "Washington", "West Orange", "Woodbridge",
  "Brooklyn, NY", "Staten Island, NY",
];

function Eyebrow({ n, children }: { n: string; children: string }) {
  const spaced = children.toUpperCase().split("").join(" ");
  return <p className="eyebrow mb-3">{`${n} — ${spaced}`}</p>;
}

export default function Home() {
  return (
    <>
      {/* 1. Hero */}
      <section className="on-navy bg-navy text-white section-pad">
        <div className="container-csi grid items-center gap-12 lg:grid-cols-[1.5fr_1fr]">
          <div className="rise">
            <p className="eyebrow mb-4">Family Financial Specialists</p>
            <h1 className="text-[clamp(36px,5.4vw,64px)]">
              Financial security for America&apos;s middle class.
            </h1>
            <hr className="rule" />
            <p className="max-w-2xl text-xl text-white/90">
              Taxes, retirement, investments, insurance, wills and estates, all handled by one
              team, under one roof, for your whole household. One phone call reaches your entire
              financial world.
            </p>
            <p className="tagline mt-5 text-lg">
              We intend to be the last financial firm your family ever needs to find.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/book" className="btn">
                Book Intro Call
              </Link>
              <Link href="/membership" className="btn btn-outline">
                What Membership Includes
              </Link>
            </div>
            <p className="mt-6">
              <Link
                href="/health-check"
                className="font-display text-[15px] font-bold !text-white underline underline-offset-4"
              >
                Take Your Free Health Check
              </Link>
              <span className="ml-3 font-display text-sm text-white/75">
                24 questions. Five minutes. See your score instantly.
              </span>
            </p>
          </div>
          <CallbackForm compact source="home-hero" />
        </div>
      </section>

      {/* 2. Trust line */}
      <section className="bg-light-gray py-10 text-center">
        <svg
          aria-hidden
          width="120"
          height="24"
          viewBox="0 0 120 24"
          className="mx-auto mb-4 opacity-60"
        >
          <path d="M4 22 A56 56 0 0 1 116 22" fill="none" stroke="#4a9fd4" strokeWidth="1.5" />
        </svg>
        <p className="container-csi font-display text-[15px] font-bold tracking-wide text-navy">
          Since 1973 · 20 branches · 22,000 member households · 9.5/10 member satisfaction (2026
          member survey)
        </p>
      </section>

      {/* 3. Not tax prep */}
      <section className="section-pad">
        <div className="container-csi">
          <Eyebrow n="01">Your whole picture</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">
            This is not a tax preparation service.
          </h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {[
              ["Your Taxes", "Filed right, planned all year, and defended if the IRS writes."],
              ["Your Retirement", "A written number, an income plan and investments managed to match."],
              ["Your Family", "Wills, insurance and a plan for the people who depend on you."],
            ].map(([t, b]) => (
              <div key={t} className="card">
                <h3 className="mb-2 text-xl">{t}</h3>
                <p>{b}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. What people walk in with */}
      <section className="bg-light-gray section-pad">
        <div className="container-csi">
          <Eyebrow n="02">What people actually walk in with</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">Start with the thing on your mind.</h2>
          <div className="mt-8 flex flex-wrap gap-3">
            {CHIPS.map((c) => (
              <Link
                key={c.t}
                href={c.href}
                className="rounded-full border border-mid-blue bg-white px-5 py-3 font-display text-[15px] font-bold !text-mid-blue hover:bg-mid-blue hover:!text-white"
              >
                {c.t}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* 5. CSI360 band */}
      <section className="on-navy bg-navy text-white section-pad">
        <div className="container-csi">
          <Image
            src="/logos/csi360_logo_with_tm__white.png"
            alt="CSI360™"
            width={220}
            height={80}
            className="mb-6 h-16 w-auto"
          />
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">
            Your Financial Life. Fully Integrated.™
          </h2>
          <p className="tagline mt-3 text-lg">One Team | One Plan | Total Clarity</p>
          <ol className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {PILLARS.map((p, i) => (
              <li
                key={p}
                className="rounded-xl border border-white/20 border-t-[3px] border-t-light-blue bg-white/5 p-5"
              >
                <span className="eyebrow">{`0${i + 1}`}</span>
                <p className="mt-1 font-display text-lg font-bold">{p}</p>
              </li>
            ))}
          </ol>
          <p className="mt-8 text-lg text-white/90">
            90 minutes. A written summary. Your next steps, in order.
          </p>
          <Link href="/360-review" className="btn btn-outline mt-6">
            See how CSI360™ works
          </Link>
        </div>
      </section>

      {/* 6. Lead advisor */}
      <section className="section-pad">
        <div className="container-csi">
          <Eyebrow n="03">Your team</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">
            A lead advisor who quarterbacks the whole thing.
          </h2>
          <p className="mt-4 max-w-2xl">
            One person knows your household and calls the plays. Specialists join the moment you
            need them, so you never have to repeat your story.
          </p>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <div className="card !bg-navy text-white">
              <h3 className="mb-2 !text-white">Lead advisor</h3>
              <p className="text-white/90">Your quarterback. Your one point of contact.</p>
            </div>
            {TEAM.map(([role, who]) => (
              <div key={role} className="card">
                <h3 className="mb-1 text-lg">{role}</h3>
                <p>{who}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Health score */}
      <section className="on-navy bg-mid-blue text-white section-pad">
        <div className="container-csi grid items-center gap-12 md:grid-cols-2">
          <div>
            <Eyebrow n="04">Financial Health Score</Eyebrow>
            <h2 className="text-[clamp(30px,4vw,46px)]">How healthy is your financial life?</h2>
            <p className="mt-4 text-lg text-white/95">
              Answer 24 quick questions and get your free score. About five minutes. No documents
              needed.
            </p>
            <Link href="/health-check" className="btn btn-outline mt-6">
              Take your free Health Check
            </Link>
          </div>
          <div className="mx-auto text-center">
            <svg viewBox="0 0 220 130" className="w-64" role="img" aria-label="Sample score gauge reading 63">
              <path d="M20 110 A90 90 0 0 1 200 110" fill="none" stroke="rgba(255,255,255,.25)" strokeWidth="16" strokeLinecap="round" />
              <path d="M20 110 A90 90 0 0 1 150 29" fill="none" stroke="#fff" strokeWidth="16" strokeLinecap="round" />
              <text x="110" y="100" textAnchor="middle" fontSize="44" fontWeight="700" fill="#fff" fontFamily="Georgia, serif">63</text>
            </svg>
            <p className="font-display text-sm font-bold uppercase tracking-widest">A typical first score</p>
          </div>
        </div>
      </section>

      {/* 8. Membership */}
      <section className="section-pad">
        <div className="container-csi grid gap-12 md:grid-cols-2">
          <div>
            <Eyebrow n="05">Membership</Eyebrow>
            <h2 className="text-[clamp(30px,4vw,46px)]">Clients here are members.</h2>
            <p className="mt-4">
              Use any one CSI service and you are a member. The rest is already waiting for you.
            </p>
            <Link href="/membership" className="btn mt-6">
              What you get as a member
            </Link>
          </div>
          <div className="card">
            <h3 className="mb-4 text-lg">Included with membership</h3>
            <ul className="checklist">
              <li>One number to call: {PHONE}</li>
              <li>A lead advisor who remembers your family</li>
              <li>Your team assigned up front</li>
              <li>Longer meetings, no rushing</li>
              <li>Your CSI360™ checkup included</li>
              <li>Priced for your household</li>
            </ul>
          </div>
        </div>
      </section>

      {/* 9. Life stages */}
      <section className="bg-light-gray section-pad">
        <div className="container-csi">
          <Eyebrow n="06">Every stage</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">We plan to grow old with your family.</h2>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {STAGES.map(([age, line]) => (
              <div key={age} className="card text-center">
                <p className="font-title text-3xl font-bold text-navy">{age}</p>
                <p className="mt-1 font-display text-sm font-semibold text-mid-blue">{line}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 10. Branches */}
      <section className="section-pad">
        <div className="container-csi">
          <Eyebrow n="07">Close to home</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">20 branches. 18 in New Jersey, 2 in New York.</h2>
          <ul className="mt-8 grid grid-cols-2 gap-x-6 gap-y-3 font-display text-[15px] font-semibold text-navy sm:grid-cols-3 lg:grid-cols-4">
            {TOWNS.map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
          <Link href="/locations" className="btn btn-outline mt-8">
            Find your branch
          </Link>
        </div>
      </section>

      {/* 11. Testimonials (placeholders) */}
      <section className="bg-light-gray section-pad">
        <div className="container-csi">
          <Eyebrow n="08">In their words</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">9.5/10 member satisfaction.</h2>
          <p className="mt-2 font-display text-sm text-disclosure">2026 member survey.</p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {[1, 2, 3].map((n) => (
              <figure key={n} className="card">
                <blockquote className="italic">
                  [Placeholder quote {n}. Replace with an approved member testimonial.]
                </blockquote>
                <figcaption className="mt-3 font-display text-sm font-bold text-navy">
                  Member name, town
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* 12. Three doors */}
      <section className="section-pad">
        <div className="container-csi">
          <Eyebrow n="09">Where do you fit?</Eyebrow>
          <h2 className="max-w-3xl text-[clamp(30px,4vw,46px)]">Three doors, one family firm.</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {[
              ["Families and retirees", "Membership", "/membership"],
              ["A household with a business", "Services", "/services"],
              ["CPAs and practice owners", "Sell your practice", "/sell-your-practice"],
            ].map(([who, cta, href]) => (
              <Link key={who} href={href} className="card block !text-ink">
                <h3 className="mb-2 text-xl">{who}</h3>
                <p className="font-display text-sm font-bold text-mid-blue">{cta} →</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* 13. Contact */}
      <section className="on-navy bg-navy text-white section-pad">
        <div className="container-csi grid items-center gap-12 md:grid-cols-2">
          <div>
            <h2 className="text-[clamp(30px,4vw,46px)]">One call starts everything.</h2>
            <p className="mt-4 text-lg text-white/90">
              Your first conversation is Complimentary &amp; Commitment-Free!
            </p>
            <a href={PHONE_TEL} className="mt-6 inline-block font-display text-2xl font-bold !text-white">
              {PHONE}
            </a>
          </div>
          <CallbackForm source="home-contact" />
        </div>
      </section>
    </>
  );
}
