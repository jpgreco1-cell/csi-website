import type { Metadata } from "next";
import { GenericForm } from "@/components/GenericForm";
import { Eyebrow, PageHero } from "@/components/ui";
import { MA_POINTS } from "@/lib/more-content";

export const metadata: Metadata = {
  title: "Sell Your Practice | CSI Group®",
  description: "A strategic transition for your practice. Your clients keep their advisor and gain a whole team.",
};

export default function Page() {
  return (
    <>
      <PageHero
        eyebrow="For firm owners"
        title="A strategic transition for your practice."
        lead="Your clients keep their advisor and gain a whole team. You get a succession plan that respects what you built."
      >
        {/* This line appears only on this page. */}
        <p className="tagline mt-5 text-lg">Relinquish Stress. Let Us Buy Your Success©</p>
      </PageHero>

      <section className="section-pad">
        <div className="container-csi grid gap-12 md:grid-cols-2">
          <div>
            <Eyebrow n="01">Leave no stone unturned</Eyebrow>
            <h2 className="text-[clamp(28px,3.6vw,42px)]">What a transition with CSI looks like.</h2>
            <ul className="checklist mt-6 text-lg">
              {MA_POINTS.map((p) => (
                <li key={p}>{p}</li>
              ))}
            </ul>
            <p className="mt-6 text-[15px]">
              Prefer to start with an email? Write to{" "}
              <a href="mailto:joinus@csicpa.com">joinus@csicpa.com</a>. Conversations are
              confidential.
            </p>
          </div>
          <GenericForm
            source="sell-your-practice"
            consent
            fields={[
              { name: "name", label: "Your name", required: true, autoComplete: "name" },
              { name: "firm", label: "Practice name", required: true, autoComplete: "organization" },
              { name: "email", label: "Email", type: "email", required: true, autoComplete: "email" },
              { name: "phone", label: "Phone", type: "tel", required: true, autoComplete: "tel" },
              { name: "message", label: "Tell us about your practice", type: "textarea" },
            ]}
            submit="Start a confidential conversation"
            success="Thank you. Someone from our team will reach out confidentially."
          />
        </div>
      </section>
    </>
  );
}
