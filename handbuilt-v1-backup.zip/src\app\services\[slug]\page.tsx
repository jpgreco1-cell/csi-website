import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CallbackForm } from "@/components/Forms";
import { Eyebrow, PageHero } from "@/components/ui";
import { SERVICE_PAGES } from "@/lib/content";

export function generateStaticParams() {
  return SERVICE_PAGES.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({
  params,
}: PageProps<"/services/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const s = SERVICE_PAGES.find((x) => x.slug === slug);
  return s ? { title: `${s.name} | CSI Group®`, description: s.blurb } : {};
}

export default async function Page({ params }: PageProps<"/services/[slug]">) {
  const { slug } = await params;
  const s = SERVICE_PAGES.find((x) => x.slug === slug);
  if (!s) notFound();

  return (
    <>
      <PageHero eyebrow={`Services · ${s.num}`} title={s.name} lead={s.blurb} />
      <section className="section-pad">
        <div className="container-csi grid gap-12 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <Eyebrow n="01">What this covers for you</Eyebrow>
            <ul className="checklist mt-4 text-lg">
              {s.points.map((p) => (
                <li key={p}>{p}</li>
              ))}
            </ul>
            <div className="card mt-10">
              <p className="eyebrow mb-2">How it fits the rest of your plan</p>
              <p>{s.fits}</p>
            </div>
          </div>
          <div>
            <h2 className="mb-4 text-2xl">Talk to a specialist</h2>
            <CallbackForm source={`service-${s.slug}`} />
          </div>
        </div>
      </section>
    </>
  );
}
