import type { Metadata } from "next";
import Link from "next/link";
import { CtaBand, Eyebrow, PageHero } from "@/components/ui";
import { SERVICE_PAGES } from "@/lib/content";

export const metadata: Metadata = {
  title: "Services | CSI Group®",
  description:
    "Tax, wealth management, wills and estates, insurance and the CSI360™ checkup, coordinated by one lead advisor.",
};

export default function Page() {
  return (
    <>
      <PageHero
        eyebrow="Services"
        title="Five services. One team. One plan."
        lead="Everything your household needs, under one roof, and coordinated by a lead advisor who holds the big picture."
      />
      <section className="section-pad">
        <div className="container-csi">
          <Eyebrow n="01">What we do</Eyebrow>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {SERVICE_PAGES.map((s) => (
              <Link key={s.slug} href={`/services/${s.slug}`} className="card block !text-ink">
                <p className="eyebrow mb-2">{s.num}</p>
                <h2 className="!font-display !text-2xl !leading-tight">{s.name}</h2>
                <p className="mt-3">{s.blurb}</p>
                <p className="mt-4 font-display text-sm font-bold text-mid-blue">{s.cta} →</p>
              </Link>
            ))}
            <Link href="/360-review" className="card block !bg-navy !text-white">
              <p className="eyebrow mb-2 !text-sky-blue">05</p>
              <h2 className="!font-display !text-2xl !leading-tight !text-white">
                CSI360™ Financial Health Checkup
              </h2>
              <p className="mt-3 text-white/90">
                A physical for your financial life: the seven-pillar checkup that ties every other
                service into one plan.
              </p>
              <p className="mt-4 font-display text-sm font-bold text-sky-blue">
                See how the 360 checkup works →
              </p>
            </Link>
          </div>
        </div>
      </section>
      <CtaBand title="Not sure where to start?" text="Tell us what is on your mind. Your first conversation is Complimentary & Commitment-Free!" />
    </>
  );
}
