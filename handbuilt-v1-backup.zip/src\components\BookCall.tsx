"use client";

import { useState } from "react";
import { CONSENT_TEXT, postLead } from "@/lib/lead";

const NEEDS = ["Taxes", "Retirement planning", "Investments", "Wills and estate", "Insurance"];
const NOTHING = "Nothing else for now";

const BRANCHES = [
  "Bedminster", "Brick", "Califon", "East Windsor", "Ewing", "Freehold", "Hillsborough",
  "Kendall Park", "Manahawkin", "Matawan", "Mountain Lakes", "Mountainside", "Red Bank",
  "Sicklerville", "Wall Township", "Washington", "West Orange", "Woodbridge",
  "Brooklyn, NY", "Staten Island, NY", "Phone or video (no branch visit)",
];

const TIMES = ["9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"];

const field =
  "w-full rounded-md border border-navy/25 bg-white px-3 py-3 font-display text-[15px] text-ink";

const TOTAL = 6;

function nextBusinessDays(n: number) {
  const out: { value: string; label: string }[] = [];
  const d = new Date();
  while (out.length < n) {
    d.setDate(d.getDate() + 1);
    const wd = d.getDay();
    if (wd === 0 || wd === 6) continue;
    out.push({
      value: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`,
      label: d.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" }),
    });
  }
  return out;
}

function Choice({
  label,
  on,
  multi,
  onClick,
}: {
  label: string;
  on: boolean;
  multi?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      role={multi ? "checkbox" : "radio"}
      aria-checked={on}
      onClick={onClick}
      className={`cursor-pointer rounded-lg border-2 px-4 py-3.5 text-left font-display text-[15px] font-semibold transition-colors ${
        on
          ? "border-mid-blue bg-mid-blue text-white"
          : "border-navy/20 bg-white text-navy hover:border-mid-blue"
      }`}
    >
      {label}
    </button>
  );
}

export function BookCall() {
  const [step, setStep] = useState(1);
  const [need, setNeed] = useState("");
  const [also, setAlso] = useState<string[]>([]);
  const [household, setHousehold] = useState("");
  const [handled, setHandled] = useState("");
  const [contact, setContact] = useState({ name: "", phone: "", email: "", consent: false });
  const [branch, setBranch] = useState("");
  const [day, setDay] = useState("");
  const [dayLabel, setDayLabel] = useState("");
  const [time, setTime] = useState("");
  // Dates depend on "today", so compute them in the click handler, not during prerender.
  const [days, setDays] = useState<{ value: string; label: string }[]>([]);
  const [done, setDone] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  const ok =
    (step === 1 && need !== "") ||
    (step === 2 && also.length > 0) ||
    (step === 3 && household !== "") ||
    (step === 4 && handled !== "") ||
    (step === 5 &&
      contact.name.trim() !== "" &&
      contact.phone.trim() !== "" &&
      /\S+@\S+\.\S+/.test(contact.email) &&
      contact.consent) ||
    (step === 6 && branch !== "" && day !== "" && time !== "");

  function toggleAlso(v: string) {
    setAlso((cur) => {
      if (v === NOTHING) return cur.includes(NOTHING) ? [] : [NOTHING];
      const base = cur.filter((x) => x !== NOTHING);
      return base.includes(v) ? base.filter((x) => x !== v) : [...base, v];
    });
  }

  async function finish() {
    setSending(true);
    setError("");
    try {
      await postLead({
        source: "book-intro-call",
        need,
        alsoAddress: also,
        household,
        handledToday: handled,
        name: contact.name,
        phone: contact.phone,
        email: contact.email,
        consent: contact.consent,
        branch,
        day,
        time,
      });
      setDone(true);
    } catch {
      setError("Something went wrong. Please try again, or call 1-800-TAX-LAWS®.");
    } finally {
      setSending(false);
    }
  }

  const first = contact.name.trim().split(/\s+/)[0];

  if (done) {
    return (
      <Shell>
        <p className="eyebrow mb-3">You are booked</p>
        <h1 className="text-[clamp(30px,4vw,44px)]">Thank you, {first}.</h1>
        <hr className="rule" />
        <p className="text-lg">
          We have you down for <strong>{dayLabel}</strong> at <strong>{time}</strong>
          {branch.startsWith("Phone") ? ", by phone or video" : ` at our ${branch} branch`}, to talk
          about {need.toLowerCase()}.
        </p>
        <p className="mt-3">
          {/* TODO: no confirmation message is sent yet. Wire email/text confirmation before launch. */}
          A member of our team will confirm with you shortly.
        </p>
        <p className="tagline mt-6">Whatever life brings, you&apos;ll never face it alone.</p>
      </Shell>
    );
  }

  return (
    <Shell>
      <div
        className="mb-6 h-2 overflow-hidden rounded-full bg-navy/10"
        role="progressbar"
        aria-valuenow={step}
        aria-valuemin={1}
        aria-valuemax={TOTAL}
        aria-label="Progress"
      >
        <div
          className="h-full bg-light-blue transition-[width] duration-300"
          style={{ width: `${(step / TOTAL) * 100}%` }}
        />
      </div>
      <p className="eyebrow mb-2">
        Step {step} of {TOTAL}
      </p>

      {step === 1 && (
        <Q title="What is the most urgent thing on your mind?">
          {NEEDS.map((n) => (
            <Choice key={n} label={n} on={need === n} onClick={() => setNeed(n)} />
          ))}
        </Q>
      )}

      {step === 2 && (
        <Q title="What else would you like addressed?" hint="Select all that apply.">
          {[...NEEDS, NOTHING].map((n) => (
            <Choice key={n} label={n} multi on={also.includes(n)} onClick={() => toggleAlso(n)} />
          ))}
        </Q>
      )}

      {step === 3 && (
        <Q title="Where is your household right now?">
          {[
            "Working and raising a family",
            "Approaching retirement",
            "Newly retired",
            "Settling an estate",
          ].map((n) => (
            <Choice key={n} label={n} on={household === n} onClick={() => setHousehold(n)} />
          ))}
        </Q>
      )}

      {step === 4 && (
        <Q title="How is your financial life handled today?">
          {[
            "One tax preparer",
            "Several separate professionals",
            "Mostly on my own",
            "Not sure where things stand",
          ].map((n) => (
            <Choice key={n} label={n} on={handled === n} onClick={() => setHandled(n)} />
          ))}
        </Q>
      )}

      {step === 5 && (
        <div>
          <h1 className="text-[clamp(24px,3.2vw,34px)]">How can we reach you?</h1>
          <div className="mt-6 space-y-3">
            <input
              value={contact.name}
              onChange={(e) => setContact({ ...contact, name: e.target.value })}
              placeholder="Full name"
              autoComplete="name"
              aria-label="Full name"
              className={field}
            />
            <input
              value={contact.phone}
              onChange={(e) => setContact({ ...contact, phone: e.target.value })}
              type="tel"
              placeholder="Phone"
              autoComplete="tel"
              aria-label="Phone"
              className={field}
            />
            <input
              value={contact.email}
              onChange={(e) => setContact({ ...contact, email: e.target.value })}
              type="email"
              placeholder="Email"
              autoComplete="email"
              aria-label="Email"
              className={field}
            />
            <label className="flex items-start gap-2 text-[13px] leading-snug">
              <input
                type="checkbox"
                checked={contact.consent}
                onChange={(e) => setContact({ ...contact, consent: e.target.checked })}
                className="mt-1"
              />
              <span>{CONSENT_TEXT}</span>
            </label>
          </div>
        </div>
      )}

      {step === 6 && (
        <div>
          <h1 className="text-[clamp(24px,3.2vw,34px)]">Pick a branch, a day and a time.</h1>
          <div className="mt-6 space-y-3">
            <label className="block">
              <span className="eyebrow mb-1 block">Nearest branch</span>
              <select value={branch} onChange={(e) => setBranch(e.target.value)} className={field}>
                <option value="">Choose a branch</option>
                {BRANCHES.map((b) => (
                  <option key={b}>{b}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="eyebrow mb-1 block">Day</span>
              <select
                value={day}
                onChange={(e) => {
                  setDay(e.target.value);
                  setDayLabel(days.find((d) => d.value === e.target.value)?.label ?? "");
                }}
                className={field}
              >
                <option value="">Choose a day</option>
                {days.map((d) => (
                  <option key={d.value} value={d.value}>
                    {d.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="eyebrow mb-1 block">Time</span>
              <select value={time} onChange={(e) => setTime(e.target.value)} className={field}>
                <option value="">Choose a time</option>
                {TIMES.map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </label>
          </div>
          {error && (
            <p role="alert" className="mt-3 text-sm text-navy">
              {error}
            </p>
          )}
        </div>
      )}

      <div className="mt-8 flex items-center justify-between">
        <button
          type="button"
          className="btn btn-outline"
          onClick={() => setStep(step - 1)}
          style={step === 1 ? { visibility: "hidden" } : undefined}
        >
          Back
        </button>
        {step < TOTAL ? (
          <button type="button" className="btn disabled:opacity-50" disabled={!ok}
            onClick={() => {
              if (step === 5) setDays(nextBusinessDays(10));
              setStep(step + 1);
            }}
          >
            Next
          </button>
        ) : (
          <button type="button" className="btn disabled:opacity-50" disabled={!ok || sending} onClick={finish}>
            {sending ? "Booking…" : "Book my call"}
          </button>
        )}
      </div>
    </Shell>
  );
}

function Q({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h1 className="text-[clamp(24px,3.2vw,34px)]">{title}</h1>
      {hint && <p className="mt-2 text-sm text-disclosure">{hint}</p>}
      <div className="mt-6 grid gap-3">{children}</div>
    </div>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <section className="bg-light-gray py-14 md:py-20">
      <div className="mx-auto w-full max-w-[720px] px-6">
        <div className="card rise !p-8 md:!p-10">{children}</div>
      </div>
    </section>
  );
}
