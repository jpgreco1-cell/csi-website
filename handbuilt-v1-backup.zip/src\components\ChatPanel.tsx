"use client";

import { useState } from "react";

type Msg = { from: "csi" | "you"; text: string };

// Canned answers only for now. TODO: confirm every answer with the firm before launch.
const ANSWERS: Record<string, string> = {
  Membership:
    "Clients here are members. Use any one CSI service and you are a member. Every member gets a lead advisor who quarterbacks their household and brings in specialists as needs arise.",
  Pricing:
    "Pricing depends on your household. Your first conversation is Complimentary & Commitment-Free!, and what you pay for the work is about what you are likely paying for a tax return now.",
  Branches:
    "We have 20 branches: 18 in New Jersey and 2 in New York. Our headquarters is at 1599 NJ-34, Wall Township, NJ 07727. See the Locations page for every address.",
  "CSI360™":
    "CSI360™ is a physical for your financial life. In about 90 minutes you get a written summary and your next steps in order.",
  "Tax or estate":
    "Our CPAs and IRS enrolled agents handle taxes, and our attorneys handle wills and estates. Your lead advisor coordinates both.",
};

export function ChatPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [msgs, setMsgs] = useState<Msg[]>([
    { from: "csi", text: "Hi, I'm Ask CSI. What can I help you with today?" },
  ]);

  if (!open) return null;

  function ask(q: string) {
    setMsgs((m) => [
      ...m,
      { from: "you", text: q },
      {
        from: "csi",
        text:
          ANSWERS[q] ??
          "I'm not sure about that one. Would you like a callback from our team?",
      },
    ]);
  }

  return (
    <aside
      role="dialog"
      aria-label="Ask CSI"
      className="fixed bottom-0 right-0 z-50 flex h-[min(560px,100dvh)] w-full max-w-[380px] flex-col rounded-t-xl bg-white shadow-[0_14px_40px_rgba(30,58,95,0.25)] md:bottom-4 md:right-4 md:rounded-xl"
    >
      <div className="on-navy flex items-center justify-between rounded-t-xl bg-navy px-5 py-4 text-white">
        <h2 className="!font-display !text-lg !text-white">Ask CSI</h2>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close chat"
          className="cursor-pointer font-display text-sm font-bold"
        >
          Close
        </button>
      </div>
      <div className="flex-1 space-y-3 overflow-y-auto p-4 text-[15px]">
        {msgs.map((m, i) => (
          <p
            key={i}
            className={
              m.from === "csi"
                ? "max-w-[85%] rounded-lg bg-light-gray p-3"
                : "ml-auto max-w-[85%] rounded-lg bg-mid-blue p-3 text-white"
            }
          >
            {m.text}
          </p>
        ))}
      </div>
      <div className="flex flex-wrap gap-2 border-t border-navy/10 p-3">
        {Object.keys(ANSWERS).map((q) => (
          <button
            key={q}
            type="button"
            onClick={() => ask(q)}
            className="cursor-pointer rounded-full border border-mid-blue px-3 py-1.5 font-display text-xs font-bold text-mid-blue hover:bg-mid-blue hover:text-white"
          >
            {q}
          </button>
        ))}
        <button
          type="button"
          onClick={() => ask("Something else")}
          className="cursor-pointer rounded-full border border-navy/30 px-3 py-1.5 font-display text-xs font-bold text-navy"
        >
          Something else
        </button>
      </div>
    </aside>
  );
}
