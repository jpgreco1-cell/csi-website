"use client";

import { useState } from "react";

const CONSENT =
  "I agree that CSI Group may contact me by email, phone or text about my results and services. Message and data rates may apply. Consent is not a condition of purchase.";

async function postLead(payload: Record<string, unknown>) {
  const res = await fetch("/api/lead", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...payload, ts: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error("Request failed");
}

const field =
  "w-full rounded-md border border-navy/25 bg-white px-3 py-3 font-display text-[15px] text-ink placeholder:text-disclosure";

/** Compact callback form. Collects a phone number, so the consent box is required. */
export function CallbackForm({
  compact = false,
  source = "callback",
}: {
  compact?: boolean;
  source?: string;
}) {
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setState("sending");
    try {
      await postLead({
        source,
        name: f.get("name"),
        phone: f.get("phone"),
        email: f.get("email"),
        consent: f.get("consent") === "on",
      });
      setState("done");
    } catch {
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <div className="card text-navy" role="status">
        <h3 className="mb-2 text-xl">Thank you.</h3>
        <p>A member of our team will call you back. Whatever life brings, you&apos;ll never face it alone.</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="card space-y-3 text-ink">
      <h3 className="text-xl">Request a callback</h3>
      <label className="block">
        <span className="sr-only">Name</span>
        <input name="name" required placeholder="Your name" autoComplete="name" className={field} />
      </label>
      <label className="block">
        <span className="sr-only">Phone</span>
        <input
          name="phone"
          type="tel"
          required
          placeholder="Phone"
          autoComplete="tel"
          className={field}
        />
      </label>
      {!compact && (
        <label className="block">
          <span className="sr-only">Email</span>
          <input
            name="email"
            type="email"
            placeholder="Email (optional)"
            autoComplete="email"
            className={field}
          />
        </label>
      )}
      <label className="flex items-start gap-2 text-[13px] leading-snug text-ink">
        <input name="consent" type="checkbox" required className="mt-1" />
        <span>{CONSENT}</span>
      </label>
      <button type="submit" disabled={state === "sending"} className="btn w-full">
        {state === "sending" ? "Sending…" : "Call me back"}
      </button>
      {state === "error" && (
        <p role="alert" className="text-sm text-navy">
          Something went wrong. Please call 1-800-TAX-LAWS® instead.
        </p>
      )}
    </form>
  );
}

export function NewsletterForm() {
  const [done, setDone] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    try {
      await postLead({ source: "newsletter", email: f.get("email") });
      setDone(true);
    } catch {
      /* leave the form in place so they can retry */
    }
  }

  if (done) return <p className="text-sm text-white">Thank you. You are subscribed.</p>;

  return (
    <form onSubmit={onSubmit} className="space-y-2">
      <label className="block text-sm text-white/85" htmlFor="nl-email">
        Free newsletter. Free of charge, and you can leave any time.
      </label>
      <div className="flex gap-2">
        <input
          id="nl-email"
          name="email"
          type="email"
          required
          placeholder="Email"
          autoComplete="email"
          className={`${field} !py-2`}
        />
        <button type="submit" className="btn !px-4 !py-2">
          Join
        </button>
      </div>
    </form>
  );
}
