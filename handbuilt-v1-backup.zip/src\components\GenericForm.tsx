"use client";

import { useState } from "react";
import { CONSENT_TEXT, postLead } from "@/lib/lead";

export type FormField = {
  name: string;
  label: string;
  type?: "text" | "email" | "tel" | "select" | "textarea";
  required?: boolean;
  options?: string[];
  autoComplete?: string;
};

const field =
  "w-full rounded-md border border-navy/25 bg-white px-3 py-3 font-display text-[15px] text-ink placeholder:text-disclosure";

/**
 * Small configurable lead form. Set `consent` whenever a phone number is collected,
 * so the SMS/phone consent checkbox is required.
 */
export function GenericForm({
  source,
  fields,
  submit,
  success,
  consent = false,
  extra = {},
}: {
  source: string;
  fields: FormField[];
  submit: string;
  success: string;
  consent?: boolean;
  extra?: Record<string, unknown>;
}) {
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const payload: Record<string, unknown> = { source, ...extra };
    for (const fl of fields) payload[fl.name] = f.get(fl.name);
    if (consent) payload.consent = f.get("consent") === "on";
    setState("sending");
    try {
      await postLead(payload);
      setState("done");
    } catch {
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <div className="card" role="status">
        <h3 className="mb-2 text-xl">Thank you.</h3>
        <p>{success}</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="card space-y-3 text-ink">
      {fields.map((fl) => (
        <label key={fl.name} className="block">
          <span className="sr-only">{fl.label}</span>
          {fl.type === "textarea" ? (
            <textarea
              name={fl.name}
              required={fl.required}
              placeholder={fl.label}
              rows={4}
              className={field}
            />
          ) : fl.type === "select" ? (
            <select name={fl.name} required={fl.required} defaultValue="" className={field}>
              <option value="" disabled>
                {fl.label}
              </option>
              {fl.options?.map((o) => (
                <option key={o}>{o}</option>
              ))}
            </select>
          ) : (
            <input
              name={fl.name}
              type={fl.type ?? "text"}
              required={fl.required}
              placeholder={fl.label}
              autoComplete={fl.autoComplete}
              className={field}
            />
          )}
        </label>
      ))}
      {consent && (
        <label className="flex items-start gap-2 text-[13px] leading-snug">
          <input name="consent" type="checkbox" required className="mt-1" />
          <span>{CONSENT_TEXT}</span>
        </label>
      )}
      <button type="submit" disabled={state === "sending"} className="btn w-full">
        {state === "sending" ? "Sending…" : submit}
      </button>
      {state === "error" && (
        <p role="alert" className="text-sm text-navy">
          Something went wrong. Please call 1-800-TAX-LAWS® instead.
        </p>
      )}
    </form>
  );
}
