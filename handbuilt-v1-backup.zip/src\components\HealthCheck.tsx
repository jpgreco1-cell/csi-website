"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  band,
  PILLARS,
  QUESTIONS,
  scoreAnswers,
  type Answers,
} from "@/lib/healthcheck";
import { CONSENT_TEXT, postLead } from "@/lib/lead";

const field =
  "w-full rounded-md border border-navy/25 bg-white px-3 py-3 font-display text-[15px] text-ink";

type Screen = "intro" | "question" | "capture" | "results";

export function HealthCheck() {
  const [screen, setScreen] = useState<Screen>("intro");
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<Answers>({});
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);

  const result = useMemo(() => scoreAnswers(answers), [answers]);
  const q = QUESTIONS[i];
  const picked = answers[q.id] ?? [];

  function choose(label: string) {
    setAnswers((a) => {
      if (!q.multi) return { ...a, [q.id]: [label] };
      const cur = a[q.id] ?? [];
      const none = "None of these";
      let next: string[];
      if (label === none) next = cur.includes(none) ? [] : [none];
      else {
        next = cur.filter((x) => x !== none);
        next = next.includes(label) ? next.filter((x) => x !== label) : [...next, label];
      }
      return { ...a, [q.id]: next };
    });
  }

  function next() {
    if (i < QUESTIONS.length - 1) setI(i + 1);
    else setScreen("capture");
  }

  async function submitCapture(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setSending(true);
    setError("");
    try {
      await postLead({
        source: "health-check",
        firstName: f.get("first"),
        lastName: f.get("last"),
        email: f.get("email"),
        mobile: f.get("mobile"),
        consent: f.get("consent") === "on",
        answers,
        score: result.total,
        pillarScores: result.pillars,
      });
      setScreen("results");
    } catch {
      setError("Something went wrong. Please try again, or call 1-800-TAX-LAWS®.");
    } finally {
      setSending(false);
    }
  }

  if (screen === "intro") {
    return (
      <Shell>
        <p className="eyebrow mb-3">Financial Health Score</p>
        <h1 className="text-[clamp(32px,4.6vw,52px)]">How healthy is your financial life?</h1>
        <hr className="rule" />
        <p className="text-lg">
          Answer 24 quick questions and get your free Financial Health Score. It takes about five
          minutes. No documents needed.
        </p>
        <button type="button" className="btn mt-6" onClick={() => setScreen("question")}>
          Start my Health Check
        </button>
        <p className="tagline mt-6">
          From the family firm that has guided 22,000 households since 1973.
        </p>
      </Shell>
    );
  }

  if (screen === "question") {
    const pct = Math.round((i / QUESTIONS.length) * 100);
    return (
      <Shell>
        <div
          className="mb-6 h-2 overflow-hidden rounded-full bg-navy/10"
          role="progressbar"
          aria-valuenow={pct}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Progress"
        >
          <div className="h-full bg-light-blue transition-[width] duration-300" style={{ width: `${pct}%` }} />
        </div>
        <p className="eyebrow mb-2">
          Question {i + 1} of {QUESTIONS.length}
        </p>
        <h2 className="text-[clamp(24px,3.2vw,34px)]">{q.prompt}</h2>
        {q.kind === "profile" && (
          <p className="mt-2 text-sm text-disclosure">This helps us personalize your results.</p>
        )}
        {q.multi && <p className="mt-2 text-sm text-disclosure">Select all that apply.</p>}
        <div className="mt-6 grid gap-3" role={q.multi ? "group" : "radiogroup"} aria-label={q.prompt}>
          {q.options.map((o) => {
            const on = picked.includes(o.label);
            return (
              <button
                key={o.label}
                type="button"
                role={q.multi ? "checkbox" : "radio"}
                aria-checked={on}
                onClick={() => choose(o.label)}
                className={`cursor-pointer rounded-lg border-2 px-4 py-3.5 text-left font-display text-[15px] font-semibold transition-colors ${
                  on
                    ? "border-mid-blue bg-mid-blue text-white"
                    : "border-navy/20 bg-white text-navy hover:border-mid-blue"
                }`}
              >
                {o.label}
              </button>
            );
          })}
        </div>
        <div className="mt-8 flex items-center justify-between">
          <button
            type="button"
            className="btn btn-outline"
            disabled={i === 0}
            onClick={() => setI(i - 1)}
            style={i === 0 ? { visibility: "hidden" } : undefined}
          >
            Back
          </button>
          <button type="button" className="btn disabled:opacity-50" disabled={picked.length === 0} onClick={next}>
            {i === QUESTIONS.length - 1 ? "See my score" : "Next"}
          </button>
        </div>
      </Shell>
    );
  }

  if (screen === "capture") {
    return (
      <Shell>
        <h1 className="text-[clamp(30px,4vw,44px)]">Your score is ready.</h1>
        <p className="mt-3">Tell us where to send it.</p>
        <form onSubmit={submitCapture} className="mt-6 space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <input name="first" required placeholder="First name" autoComplete="given-name" aria-label="First name" className={field} />
            <input name="last" required placeholder="Last name" autoComplete="family-name" aria-label="Last name" className={field} />
          </div>
          <input name="email" type="email" required placeholder="Email" autoComplete="email" aria-label="Email" className={field} />
          <input name="mobile" type="tel" required placeholder="Mobile phone" autoComplete="tel" aria-label="Mobile phone" className={field} />
          <label className="flex items-start gap-2 text-[13px] leading-snug">
            <input name="consent" type="checkbox" required className="mt-1" />
            <span>{CONSENT_TEXT}</span>
          </label>
          <p className="text-sm text-disclosure">Your information is never sold.</p>
          <button type="submit" disabled={sending} className="btn">
            {sending ? "Calculating…" : "Show my score"}
          </button>
          {error && (
            <p role="alert" className="text-sm text-navy">
              {error}
            </p>
          )}
          <p className="font-display text-[11px] leading-snug text-disclosure">
            This assessment is educational and is not individualized financial, tax, legal, or
            investment advice.
          </p>
        </form>
      </Shell>
    );
  }

  return <Results answers={answers} result={result} />;
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <section className="bg-light-gray py-14 md:py-20">
      <div className="mx-auto w-full max-w-[720px] px-6">
        <div className="card rise !p-8 md:!p-10">{children}</div>
      </div>
    </section>
  );
}

function Results({
  answers,
  result,
}: {
  answers: Answers;
  result: ReturnType<typeof scoreAnswers>;
}) {
  const [shown, setShown] = useState(0);
  const b = band(result.total);
  const worry = answers["worry"]?.[0];

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const start = performance.now();
    const dur = reduce ? 1 : 1400;
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min((t - start) / dur, 1);
      setShown(Math.round(result.total * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [result.total]);

  const opportunities = [...result.perQuestion]
    .map((x, idx) => ({ ...x, idx }))
    .filter((x) => x.score < 10)
    .sort((a, c) => a.score - c.score || a.idx - c.idx)
    .slice(0, 3);

  return (
    <Shell>
      <p className="eyebrow mb-2">Your Financial Health Score</p>
      <div className="text-center">
        <svg viewBox="0 0 220 135" className="mx-auto w-72" role="img" aria-label={`Score ${result.total} out of 100`}>
          <circle cx="110" cy="110" r="104" fill="none" stroke="#4a9fd4" strokeOpacity="0.2" strokeWidth="1.5" />
          <path d="M20 110 A90 90 0 0 1 200 110" fill="none" stroke="#1e3a5f" strokeOpacity="0.12" strokeWidth="16" strokeLinecap="round" pathLength={100} />
          <path d="M20 110 A90 90 0 0 1 200 110" fill="none" stroke="#2e5f8a" strokeWidth="16" strokeLinecap="round" pathLength={100} strokeDasharray={`${shown} 100`} />
          <text x="110" y="102" textAnchor="middle" fontSize="48" fontWeight="700" fill="#1e3a5f" fontFamily="Georgia, serif">
            {shown}
          </text>
        </svg>
        <h1 className="mt-2 text-[clamp(28px,3.6vw,38px)]">{b.label}</h1>
        <p className="mx-auto mt-2 max-w-md">{b.note}</p>
      </div>

      <h2 className="mt-10 text-2xl">Your seven pillars</h2>
      <ul className="mt-4 space-y-3">
        {PILLARS.map((p, n) => {
          const v = result.pillars[p];
          return (
            <li key={p}>
              <div className="flex justify-between font-display text-sm font-bold text-navy">
                <span>{p}</span>
                <span>{v} / 20</span>
              </div>
              <div className="mt-1 h-3 overflow-hidden rounded-full bg-navy/10">
                <div
                  className="h-full rounded-full bg-mid-blue"
                  style={{
                    width: `${(v / 20) * 100}%`,
                    animation: `rise 300ms ease-out ${n * 90}ms both`,
                  }}
                />
              </div>
            </li>
          );
        })}
      </ul>

      <h2 className="mt-10 text-2xl">Your 3 biggest opportunities</h2>
      {worry && (
        <p className="tagline mt-2">You told us your #1 concern is {worry.toLowerCase()}. Let us start there.</p>
      )}
      <div className="mt-4 space-y-4">
        {opportunities.length === 0 && (
          <p>Your answers show a strong foundation. A yearly review keeps it that way.</p>
        )}
        {opportunities.map(({ q }) => (
          <div key={q.id} className="rounded-lg border-l-[3px] border-light-blue bg-light-gray p-4">
            <p className="eyebrow mb-1">{q.pillar}</p>
            <p>{q.insight}</p>
          </div>
        ))}
      </div>

      <Link href="/book" className="btn mt-10">
        Book my free intro call
      </Link>
      {/* TODO: report email is not wired yet. Confirm this line only once email sending exists. */}
      <p className="mt-4 text-sm text-disclosure">We will email a copy of your report to you.</p>
      <p className="mt-4 font-display text-[11px] leading-snug text-disclosure">
        This assessment is educational and is not individualized financial, tax, legal, or
        investment advice.
      </p>
    </Shell>
  );
}
