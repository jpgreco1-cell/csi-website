"use client";

import { useState } from "react";
import { CONSENT_TEXT, postLead } from "@/lib/lead";

const field =
  "w-full rounded-md border border-navy/25 bg-white px-3 py-3 font-display text-[15px] text-ink";

export function MatchForm() {
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setState("sending");
    try {
      await postLead({
        source: "locations-match",
        name: f.get("name"),
        townOrZip: f.get("where"),
        phone: f.get("phone"),
        consent: f.get("consent") === "on",
      });
      setState("done");
    } catch {
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <div className="card" role="status">
        <h3 className="mb-2 text-xl">Thank you.</h3>
        <p>We will call you with your nearest branch.</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="card space-y-3">
      <input name="name" required placeholder="Your name" autoComplete="name" aria-label="Your name" className={field} />
      <input name="where" required placeholder="Town or ZIP code" autoComplete="postal-code" aria-label="Town or ZIP code" className={field} />
      <input name="phone" type="tel" required placeholder="Phone" autoComplete="tel" aria-label="Phone" className={field} />
      <label className="flex items-start gap-2 text-[13px] leading-snug">
        <input name="consent" type="checkbox" required className="mt-1" />
        <span>{CONSENT_TEXT}</span>
      </label>
      <button type="submit" disabled={state === "sending"} className="btn w-full">
        {state === "sending" ? "Sending…" : "Match me to a branch"}
      </button>
      {state === "error" && (
        <p role="alert" className="text-sm text-navy">
          Something went wrong. Please call 1-800-TAX-LAWS® instead.
        </p>
      )}
    </form>
  );
}
