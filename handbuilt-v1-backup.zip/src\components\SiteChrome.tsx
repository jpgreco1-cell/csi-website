"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import {
  EMAIL,
  FOOTER_COMPANY,
  LEGAL_DISCLOSURE,
  NAV,
  PHONE,
  PHONE_TEL,
  PRINT_CODE,
  SERVICES,
} from "@/lib/site";
import { ChatPanel } from "./ChatPanel";
import { NewsletterForm } from "./Forms";

export function SiteChrome({ children }: { children: React.ReactNode }) {
  const [chatOpen, setChatOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-white focus:p-3"
      >
        Skip to content
      </a>

      {/* Utility bar */}
      <div className="on-navy bg-navy text-white">
        <div className="container-csi flex flex-wrap items-center justify-between gap-x-6 gap-y-2 py-2 text-[13px]">
          <p className="tagline hidden !text-sky-blue md:block">
            From Taxes to Retirement, Let Our Family Guide Yours.®
          </p>
          <div className="ml-auto flex flex-wrap items-center gap-x-5 gap-y-2 font-display font-semibold">
            <a href={PHONE_TEL} className="!text-white">
              {PHONE}
            </a>
            <Link href="/about" className="!text-white">
              About us
            </Link>
            <button
              type="button"
              onClick={() => setChatOpen(true)}
              className="cursor-pointer text-white"
            >
              Ask CSI
            </button>
            <Link
              href="/health-check"
              className="rounded-full bg-mid-blue px-4 py-1.5 !text-white"
            >
              Free Health Check
            </Link>
            <Link
              href="/member-login"
              className="rounded-full border border-white px-4 py-1.5 !text-white"
            >
              Member Login
            </Link>
          </div>
        </div>
      </div>

      {/* Sticky header */}
      <header className="sticky top-0 z-40 border-b border-navy/10 bg-white">
        <div className="container-csi flex items-center justify-between gap-6 py-3">
          <Link href="/" aria-label="CSI Group home">
            <Image
              src="/logos/CSIGroupLogo_2025.png"
              alt="CSI Group"
              width={160}
              height={44}
              priority
              className="h-10 w-auto"
            />
          </Link>
          <nav
            aria-label="Main"
            className="hidden items-center gap-7 font-display text-[15px] font-bold min-[900px]:flex"
          >
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} className="!text-navy hover:!text-light-blue">
                {n.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <Link href="/book" className="btn hidden !py-2.5 min-[900px]:inline-flex">
              Book Intro Call
            </Link>
            <button
              type="button"
              aria-label="Open menu"
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen((v) => !v)}
              className="cursor-pointer rounded border border-navy/20 px-3 py-2 font-display text-sm font-bold text-navy min-[900px]:hidden"
            >
              {menuOpen ? "Close" : "Menu"}
            </button>
          </div>
        </div>
        {menuOpen && (
          <nav
            aria-label="Mobile"
            className="border-t border-navy/10 bg-white px-6 pb-5 min-[900px]:hidden"
          >
            {NAV.map((n) => (
              <Link
                key={n.href}
                href={n.href}
                onClick={() => setMenuOpen(false)}
                className="block py-3 font-display font-bold !text-navy"
              >
                {n.label}
              </Link>
            ))}
            <Link href="/book" className="btn mt-2 w-full" onClick={() => setMenuOpen(false)}>
              Book Intro Call
            </Link>
          </nav>
        )}
      </header>

      <main id="main">{children}</main>

      {/* Footer */}
      <footer className="on-navy bg-navy pb-24 text-white md:pb-0">
        <div className="container-csi grid gap-10 py-16 md:grid-cols-[1.3fr_1fr_1fr_1.3fr]">
          <div>
            <Image
              src="/logos/CSIGroupLogo_2025_white.png"
              alt="CSI Group"
              width={170}
              height={46}
              className="h-11 w-auto"
            />
            <p className="tagline mt-4 !text-sky-blue">
              From Taxes to Retirement, Let Our Family Guide Yours.®
            </p>
            <address className="mt-5 text-[15px] not-italic text-white/85">
              1599 NJ-34
              <br />
              Wall Township, NJ 07727
              <br />
              <a href={PHONE_TEL} className="!text-white">
                {PHONE}
              </a>
              <br />
              <a href={`mailto:${EMAIL}`} className="!text-white">
                {EMAIL}
              </a>
              <br />
              csicpa.com
            </address>
          </div>
          <div>
            <h4 className="eyebrow mb-4">Services</h4>
            <ul className="space-y-2 text-[15px]">
              {SERVICES.map((s) => (
                <li key={s.href}>
                  <Link href={s.href} className="!text-white/85 hover:!text-white">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="eyebrow mb-4">Company</h4>
            <ul className="space-y-2 text-[15px]">
              {FOOTER_COMPANY.map((s) => (
                <li key={s.label}>
                  <Link href={s.href} className="!text-white/85 hover:!text-white">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="eyebrow mb-4">Talk to us</h4>
            <Link href="/book" className="btn mb-3 w-full">
              Book Intro Call
            </Link>
            <button
              type="button"
              onClick={() => setChatOpen(true)}
              className="mb-6 cursor-pointer font-display text-sm font-bold text-white underline underline-offset-4"
            >
              Chat with Ask CSI
            </button>
            <NewsletterForm />
          </div>
        </div>
        <div className="border-t border-white/15">
          <div className="container-csi flex flex-col gap-4 py-8">
            <p className="font-display text-[11px] leading-[1.45] text-white/70">
              {LEGAL_DISCLOSURE}
            </p>
            <p className="self-end font-display text-[11px] text-white/70">{PRINT_CODE}</p>
          </div>
        </div>
      </footer>

      {/* Mobile sticky ladder */}
      <div className="fixed inset-x-0 bottom-0 z-30 flex gap-3 border-t border-navy/10 bg-white p-3 md:hidden">
        <Link href="/health-check" className="btn btn-outline flex-1 !px-3 !py-3 text-center">
          Free Health Check
        </Link>
        <Link href="/book" className="btn flex-1 !px-3 !py-3 text-center">
          Book Intro Call
        </Link>
      </div>

      <ChatPanel open={chatOpen} onClose={() => setChatOpen(false)} />
    </>
  );
}
