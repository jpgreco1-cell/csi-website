import Link from "next/link";

export function Eyebrow({ n, children }: { n?: string; children: string }) {
  const spaced = children.toUpperCase().split("").join(" ");
  return <p className="eyebrow mb-3">{n ? `${n} — ${spaced}` : children}</p>;
}

export function PageHero({
  eyebrow,
  title,
  lead,
  aside,
  children,
}: {
  eyebrow: string;
  title: string;
  lead?: string;
  aside?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <section className="on-navy bg-navy text-white section-pad">
      <div
        className={`container-csi grid items-center gap-12 ${aside ? "lg:grid-cols-[1.5fr_1fr]" : ""}`}
      >
        <div className="rise">
          <p className="eyebrow mb-4">{eyebrow}</p>
          <h1 className="text-[clamp(34px,5vw,56px)]">{title}</h1>
          <hr className="rule" />
          {lead && <p className="max-w-2xl text-xl text-white/90">{lead}</p>}
          {children}
        </div>
        {aside}
      </div>
    </section>
  );
}

export function CtaBand({ title, text }: { title: string; text?: string }) {
  return (
    <section className="on-navy bg-mid-blue text-white section-pad">
      <div className="container-csi text-center">
        <h2 className="mx-auto max-w-3xl text-[clamp(28px,3.6vw,42px)]">{title}</h2>
        {text && <p className="mx-auto mt-3 max-w-2xl text-lg text-white/95">{text}</p>}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/book" className="btn btn-outline">
            Book Intro Call
          </Link>
          <Link href="/health-check" className="btn btn-outline">
            Take Your Free Health Check
          </Link>
        </div>
      </div>
    </section>
  );
}
