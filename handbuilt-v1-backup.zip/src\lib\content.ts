// Copy carried over from the Claude Design prototype (CSI Group Website.dc.html).

export type Service = {
  slug: string;
  num: string;
  name: string;
  cta: string;
  blurb: string;
  points: string[];
  fits: string;
};

export const SERVICE_PAGES: Service[] = [
  {
    slug: "tax",
    num: "01",
    name: "Tax Preparation & Planning",
    cta: "See how tax planning works",
    blurb:
      "Preparation and year-round planning for your household, by CPAs and IRS Enrolled Agents who see the rest of your picture.",
    points: [
      "Personal returns, federal, state and multi-state",
      "Year-round planning so April holds no surprises",
      "Audit representation and back-year cleanup",
      "Retirement withdrawals timed for the lowest lifetime tax",
    ],
    fits: "Your return is the clearest annual snapshot of your household. We read it as a planning document, not paperwork, and hand what we find to the rest of your team.",
  },
  {
    slug: "wealth",
    num: "02",
    name: "Wealth Management & Financial Advisory",
    cta: "See how the retirement plan works",
    blurb:
      "Retirement income, investments, and the plan that connects them to your taxes and your estate. Our registered investment advisor and CFP® professionals are fiduciaries, bound to act in your best interest.",
    points: [
      "Retirement income planning, Social Security timing, pension elections",
      "Investment management aligned to your tax picture",
      "Rollovers, 401(k) and 403(b) decisions explained plainly",
      "Fiduciary advice, always in your best interest, never product-first",
      "Annual review with your lead advisor",
    ],
    fits: "Investment decisions made without your tax and estate picture cost families real money. Here they are made in the same room.",
  },
  {
    slug: "estate",
    num: "03",
    name: "Wills & Estate Planning",
    cta: "See how estate planning works",
    blurb: "Licensed attorneys in house, so your documents match your plan instead of contradicting it.",
    points: [
      "Wills, trusts, powers of attorney, health care directives",
      "Estate and inheritance tax planning for NJ and NY families",
      "Probate and estate administration support",
      "Beneficiary and account titling review",
    ],
    fits: "An estate plan is only as good as the beneficiary forms and account titles behind it. Your team checks all of it together.",
  },
  {
    slug: "insurance",
    num: "04",
    name: "Insurance",
    cta: "See how a coverage review works",
    blurb: "Protection sized to your actual obligations, reviewed as those obligations change.",
    points: [
      "Life insurance sized to the mortgage, the tuition, the income gap",
      "Long-term care and disability planning",
      "Medicare guidance as you approach 65",
      "Annual policy review, no annual sales pitch",
    ],
    fits: "Policies bought a decade ago rarely match today. We review yours against your current plan, then leave it alone if it still works.",
  },
];

export const PILLARS_FULL = [
  { num: "01", title: "Tax Strategy", body: "What you owe this year, and what the next ten years look like if nothing changes." },
  { num: "02", title: "Retirement Income", body: "Which account you draw from first, and when Social Security should start." },
  { num: "03", title: "Investments", body: "Allocation and account placement, read against your tax bracket." },
  { num: "04", title: "Insurance & Risk", body: "What would happen to the household if one income stopped tomorrow." },
  { num: "05", title: "Estate & Legacy", body: "Wills, beneficiaries and titling that agree with each other." },
  { num: "06", title: "Cash Flow & Debt", body: "What comes in, what goes out, and what it costs you to carry." },
  { num: "07", title: "Family & Next Generation", body: "Aging parents, adult children, tuition, and the plan that outlives you." },
];

export const ONBOARDING = [
  { n: "1", title: "One conversation", body: "A complimentary call about where your household stands. No cost, no commitment." },
  { n: "2", title: "Use one service", body: "Taxes, a plan review, a will. Whatever you need first makes you a member." },
  {
    n: "3",
    title: "Meet your CSI360™ Team",
    body: "Your lead advisor, who is also your CPA or IRS Enrolled Agent, plus a senior advisor for the complex moments, a financial advisor or CFP®, an attorney and a member services rep. The team you keep for life.",
  },
  { n: "4", title: "Stay for life", body: "Your team grows with your family, and picks up right where you left off." },
];

export const BENEFITS = [
  { title: "One number to call", body: "Taxes, retirement, estate, insurance. One call reaches your whole financial world." },
  { title: "A lead advisor who remembers", body: "One person knows your household and carries the details from year to year, so you never start over." },
  { title: "Your team assigned up front", body: "You meet the people who will work on your plan at the start, not when something goes wrong." },
  { title: "Longer meetings", body: "Time to ask the questions you actually have, without watching the clock." },
  { title: "Your CSI360™ checkup included", body: "The seven-pillar review of your financial life comes with membership." },
  { title: "Priced for your household", body: "Built for middle-class families, with no surprises. Ask us what membership looks like for you." },
];

export type Branch = { town: string; address: string; phone: string; hq?: boolean };

export const BRANCHES: Branch[] = [
  { town: "Bedminster", address: "1430 US-206, Ste 250, Bedminster, NJ 07921", phone: "732-224-3990" },
  { town: "Brick", address: "278 Brick Blvd, Brick Township, NJ 08723", phone: "732-224-3990" },
  { town: "Califon", address: "37 School St, Califon, NJ 07830", phone: "732-224-3990" },
  { town: "East Windsor", address: "379 Princeton Hightstown Rd, Bldg 1 Fl 2, East Windsor, NJ 08512", phone: "732-224-3990" },
  { town: "Ewing", address: "34 Scotch Rd, 2nd Floor, Ewing Township, NJ 08628", phone: "732-224-3990" },
  { town: "Freehold", address: "181 South St, Freehold, NJ 07728", phone: "732-224-3990" },
  { town: "Hillsborough", address: "181 US-206, Hillsborough Township, NJ 08844", phone: "732-224-3990" },
  { town: "Kendall Park", address: "5 Allston Rd, Kendall Park, NJ 08824", phone: "732-224-3990" },
  { town: "Manahawkin", address: "157 N Main St, Manahawkin, NJ 08050", phone: "732-224-3990" },
  { town: "Matawan", address: "899 NJ-34, Matawan, NJ 07747", phone: "732-224-3990" },
  { town: "Mountain Lakes", address: "101 US-46, Mountain Lakes, NJ 07046", phone: "732-224-3990" },
  { town: "Mountainside", address: "615 Sherwood Pkwy, Mountainside, NJ 07092", phone: "732-224-3990" },
  { town: "Red Bank", address: "165 NJ-35, Red Bank, NJ 07701", phone: "732-224-3990" },
  { town: "Sicklerville", address: "300 Independence Blvd, Sicklerville, NJ 08081", phone: "732-224-3990" },
  { town: "Wall Township", address: "1599 NJ-34, Suite 2, Wall Township, NJ 07727", phone: "732-224-3990", hq: true },
  { town: "Washington", address: "157 NJ-31, Washington, NJ 07882", phone: "732-224-3990" },
  { town: "West Orange", address: "327 Valley Rd, West Orange, NJ 07052", phone: "732-224-3990" },
  { town: "Woodbridge", address: "281 Main St, Woodbridge, NJ 07095", phone: "732-224-3990" },
  { town: "Brooklyn, NY", address: "385 Jay St, Brooklyn, NY 11201", phone: "718-858-9864" },
  { town: "Staten Island, NY", address: "3996 Amboy Rd, Staten Island, NY 10308", phone: "718-266-1570" },
];

export const MILESTONES = [
  { year: "1973", title: "Brooklyn", body: "Peter Greco opens a small tax practice for families nobody else was helping." },
  { year: "1983", title: "Bensonhurst", body: "A larger office on 86th Street becomes the neighborhood destination for financial help." },
  { year: "1990", title: "Matawan, NJ", body: "The first New Jersey location opens and the firm grows across suburban households." },
  { year: "2010s", title: "Next generation", body: "James and Robert Greco take over as co-CEOs and put every service under one roof." },
  { year: "Today", title: "CSI360™", body: "One integrated plan per household, one lead advisor, and more than 80 professionals behind them." },
];
