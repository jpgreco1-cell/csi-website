export const PILLARS = [
  "Cash Flow & Debt",
  "Retirement Income",
  "Tax Strategy",
  "Investments",
  "Insurance & Risk",
  "Estate & Legacy",
  "Family & Next Generation",
] as const;

export type Pillar = (typeof PILLARS)[number];

export type Option = { label: string; score?: number };

export type Question = {
  id: string;
  kind: "profile" | "scored" | "intent";
  multi?: boolean;
  prompt: string;
  options: Option[];
  pillar?: Pillar;
  /** Plain-language insight shown when this answer is among the lowest scores. */
  insight?: string;
};

const s = (a: string, b: string, c: string): Option[] => [
  { label: a, score: 10 },
  { label: b, score: 5 },
  { label: c, score: 0 },
];

// Q1-Q6: profile, unscored.
const PROFILE: Question[] = [
  {
    id: "age",
    kind: "profile",
    prompt: "Which age range are you in?",
    options: [
      { label: "Under 30" },
      { label: "30 to 44" },
      { label: "45 to 54" },
      { label: "55 to 64" },
      { label: "65 and over" },
    ],
  },
  {
    id: "describes",
    kind: "profile",
    multi: true,
    prompt: "Which of these describe you?",
    options: [
      { label: "Married or partnered" },
      { label: "Raising children" },
      { label: "Caring for an aging parent" },
      { label: "Own a home" },
      { label: "Own a business" },
      { label: "None of these" },
    ],
  },
  {
    id: "work",
    kind: "profile",
    prompt: "What does your work life look like?",
    options: [
      { label: "Employed" },
      { label: "Self-employed" },
      { label: "Between jobs" },
      { label: "Retired" },
    ],
  },
  {
    id: "income",
    kind: "profile",
    prompt: "What is your household income?",
    options: [
      { label: "Under $75,000" },
      { label: "$75,000 to $150,000" },
      { label: "$150,000 to $250,000" },
      { label: "Over $250,000" },
      { label: "Prefer not to say" },
    ],
  },
  {
    id: "savings",
    kind: "profile",
    prompt: "About how much do you have in savings and investments?",
    options: [
      { label: "Under $50,000" },
      { label: "$50,000 to $250,000" },
      { label: "$250,000 to $1 million" },
      { label: "Over $1 million" },
      { label: "Prefer not to say" },
    ],
  },
  {
    id: "goal",
    kind: "profile",
    prompt: "What is your retirement goal?",
    options: [
      { label: "Retire in the next 5 years" },
      { label: "Retire in 5 to 15 years" },
      { label: "Retire in 15 or more years" },
      { label: "Already retired" },
      { label: "Not sure yet" },
    ],
  },
];

// Q7-Q20: scored 0/5/10, two per pillar.
const SCORED: Question[] = [
  {
    id: "cash-cover",
    kind: "scored",
    pillar: "Cash Flow & Debt",
    prompt: "If your income stopped, how long could you cover your bills?",
    options: s("Six months or more", "One to five months", "Less than a month"),
    insight:
      "A cash cushion of several months is the first thing that keeps a surprise from becoming a crisis. Yours has room to grow.",
  },
  {
    id: "cash-save",
    kind: "scored",
    pillar: "Cash Flow & Debt",
    prompt: "Do you save on purpose, every month?",
    options: s("Yes, automatically", "Sometimes, when there is money left", "No"),
    insight:
      "Saving works best when it happens before spending does. A simple automatic transfer changes the whole picture.",
  },
  {
    id: "ret-contrib",
    kind: "scored",
    pillar: "Retirement Income",
    prompt: "Are you contributing to a retirement account?",
    options: s("Yes, at a level I chose on purpose", "Yes, but only a little", "No"),
    insight:
      "Your contributions are the engine of your retirement. Getting the level right, and using every available benefit, matters more than almost anything else.",
  },
  {
    id: "ret-number",
    kind: "scored",
    pillar: "Retirement Income",
    prompt: "Do you have a written retirement number?",
    options: s("Yes, in writing", "I have a rough idea", "No"),
    insight:
      "A written retirement number turns a hope into a plan. Without one, it is hard to know whether you are on track.",
  },
  {
    id: "tax-year",
    kind: "scored",
    pillar: "Tax Strategy",
    prompt: "Do you plan your taxes all year, or only at filing time?",
    options: s("All year", "Sometimes", "Only at filing time"),
    insight:
      "Most tax savings are found before the year ends, not after. Year-round planning can change what you keep.",
  },
  {
    id: "tax-confidence",
    kind: "scored",
    pillar: "Tax Strategy",
    prompt: "How confident are you that you are not overpaying the IRS?",
    options: s("Very confident", "Somewhat confident", "Not confident"),
    insight:
      "If you are unsure whether you are overpaying, a second look from a CPA or enrolled agent is worth your time.",
  },
  {
    id: "inv-managed",
    kind: "scored",
    pillar: "Investments",
    prompt: "How are your investments managed?",
    options: s(
      "By a professional, to a plan I understand",
      "Partly by me, partly by someone else",
      "By me alone, or not at all",
    ),
    insight:
      "Investments work hardest when they follow a plan built around your goals, and someone is watching them with you.",
  },
  {
    id: "inv-fees",
    kind: "scored",
    pillar: "Investments",
    prompt: "Do you know what you pay in annual fees on your investments?",
    options: s("Yes, exactly", "Roughly", "No"),
    insight:
      "Fees quietly compound against you. Knowing what you pay is the first step to knowing what you get.",
  },
  {
    id: "ins-life",
    kind: "scored",
    pillar: "Insurance & Risk",
    prompt: "Is your life insurance enough to protect the people who depend on you?",
    options: s("Yes, reviewed recently", "Not sure", "I have none or very little"),
    insight:
      "Life insurance is meant to replace what your family would lose. It deserves a check against your life as it is today.",
  },
  {
    id: "ins-illness",
    kind: "scored",
    pillar: "Insurance & Risk",
    prompt: "What would cover the cost of a long illness or long-term care?",
    options: s("A plan I have put in place", "I would use savings", "I have not thought about it"),
    insight:
      "A long illness can undo decades of saving. There are ways to prepare, and the earlier you start the better the options.",
  },
  {
    id: "estate-will",
    kind: "scored",
    pillar: "Estate & Legacy",
    prompt: "Do you have a current will and medical and financial directives?",
    options: s("Yes, all of them", "Some of them, or they are out of date", "No"),
    insight:
      "Without a will and directives, the state decides what happens. A short meeting with an attorney puts the decision back in your hands.",
  },
  {
    id: "estate-beneficiaries",
    kind: "scored",
    pillar: "Estate & Legacy",
    prompt: "When did you last check your beneficiaries and how your accounts are titled?",
    options: s("In the last two years", "More than two years ago", "Never"),
    insight:
      "Beneficiary forms override your will. An old one can send money to the wrong person.",
  },
  {
    id: "fam-find",
    kind: "scored",
    pillar: "Family & Next Generation",
    prompt: "If something happened to you, would your family find everything?",
    options: s("Yes, it is all organized", "Some of it", "No"),
    insight:
      "An organized list of accounts, documents and contacts is a gift to the people you leave behind.",
  },
  {
    id: "fam-plan",
    kind: "scored",
    pillar: "Family & Next Generation",
    prompt: "Is there a plan for aging parents or adult children?",
    options: s("Yes, we have talked it through", "We have talked a little", "No plan yet"),
    insight:
      "Helping a parent or a grown child is easier when the plan exists before the need does.",
  },
];

// Q21-Q24: unscored intent.
const INTENT: Question[] = [
  {
    id: "advisor",
    kind: "intent",
    prompt: "Do you have a financial advisor today?",
    options: [
      { label: "Yes, and I am happy" },
      { label: "Yes, but I am looking" },
      { label: "No" },
    ],
  },
  {
    id: "last-review",
    kind: "intent",
    prompt: "When was your whole financial life last reviewed in one sitting?",
    options: [
      { label: "In the last year" },
      { label: "One to three years ago" },
      { label: "More than three years ago" },
      { label: "Never" },
    ],
  },
  {
    id: "manager",
    kind: "intent",
    prompt: "Who manages your investments?",
    options: [
      { label: "An advisor at a firm" },
      { label: "A bank or brokerage" },
      { label: "I do" },
      { label: "No one" },
    ],
  },
  {
    id: "worry",
    kind: "intent",
    prompt: "What is your number one money worry?",
    options: [
      { label: "Running out of money in retirement" },
      { label: "Paying too much in taxes" },
      { label: "Protecting my family" },
      { label: "Leaving something behind" },
      { label: "Not knowing where I stand" },
    ],
  },
];

export const QUESTIONS: Question[] = [...PROFILE, ...SCORED, ...INTENT];

export type Answers = Record<string, string[]>;

export function scoreAnswers(answers: Answers) {
  const pillars = Object.fromEntries(PILLARS.map((p) => [p, 0])) as Record<Pillar, number>;
  const perQuestion: { q: Question; score: number }[] = [];
  let raw = 0;
  for (const q of QUESTIONS) {
    if (q.kind !== "scored" || !q.pillar) continue;
    const pick = answers[q.id]?.[0];
    const score = q.options.find((o) => o.label === pick)?.score ?? 0;
    pillars[q.pillar] += score;
    raw += score;
    perQuestion.push({ q, score });
  }
  const total = Math.round((raw / 140) * 100);
  return { total, pillars, perQuestion };
}

export function band(total: number) {
  if (total >= 85)
    return { label: "Strong Foundation", note: "You are ahead of most families. A review keeps it that way." };
  if (total >= 65)
    return { label: "Solid With Gaps", note: "You have built a lot. A few gaps are worth closing, and most families score here." };
  if (total >= 40)
    return { label: "Needs Attention", note: "There is real work to do, and most families score here. The good news is it is fixable." };
  return { label: "Time for a Plan", note: "Many families start here. A plan is exactly what changes this, and we will build it with you." };
}
