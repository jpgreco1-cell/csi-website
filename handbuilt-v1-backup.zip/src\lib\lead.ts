export const CONSENT_TEXT =
  "I agree that CSI Group may contact me by email, phone or text about my results and services. Message and data rates may apply. Consent is not a condition of purchase.";

export function utmParams(): Record<string, string> {
  if (typeof window === "undefined") return {};
  const out: Record<string, string> = {};
  new URLSearchParams(window.location.search).forEach((v, k) => {
    if (k.startsWith("utm_")) out[k] = v;
  });
  return out;
}

export async function postLead(payload: Record<string, unknown>) {
  const res = await fetch("/api/lead", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...payload, ...utmParams(), ts: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error("Request failed");
}
