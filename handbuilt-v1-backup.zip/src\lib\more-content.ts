// Copy carried over from the Claude Design prototype.

export type Post = {
  slug: string;
  kicker: string;
  title: string;
  dek: string;
  /** Art direction note for the photo to be shot. Not shown on the site. */
  photo: string;
  /**
   * TODO: article bodies are not written yet. Add reviewed paragraphs here.
   * Financial, tax and estate content needs compliance review before publishing.
   */
  body: string[];
};

export const POSTS: Post[] = [
  {
    slug: "which-account-first",
    kicker: "Retirement",
    title: "Which account should you draw from first?",
    dek: "The order of withdrawals can change your lifetime tax bill more than the market will.",
    photo: "NJ couple in their 60s at a kitchen table, morning light, laptop and a paper statement between them.",
    body: [],
  },
  {
    slug: "beneficiary-form-overrides-will",
    kicker: "Estate",
    title: "The beneficiary form that overrides your will",
    dek: "Most families have at least one account pointed at the wrong person.",
    photo: "Hands and forearms only, a will being signed on a dining table, reading glasses and a mug in frame.",
    body: [],
  },
  {
    slug: "preparer-should-see-investments",
    kicker: "Tax",
    title: "Why your preparer should see your investment statements",
    dek: "Two professionals, one picture, and the money that falls between them.",
    photo: "Advisor and member side by side at a branch table looking at the same page.",
    body: [],
  },
  {
    slug: "talking-to-your-parents",
    kicker: "Family",
    title: "Talking to your parents about their plan",
    dek: "A short script for the conversation nobody wants to start.",
    photo: "Three generations on a suburban back porch, candid, late-day light.",
    body: [],
  },
];

export const CAREER_STATS = [
  { value: "1973", label: "Family owned since" },
  { value: "80+", label: "Professionals and growing" },
  { value: "20", label: "Branches in NJ and NY" },
  { value: "22,000", label: "Households counting on us" },
];

export const CAREER_REASONS = [
  { title: "You see the whole picture", body: "Nobody here works on a slice. Your tax return talks to the retirement plan, which talks to the will. You will learn parts of this business most people never touch." },
  { title: "Real relationships, real tenure", body: "Members stay for decades and their children become members. You get to watch your advice work over 20 years instead of 20 minutes." },
  { title: "A mission with teeth", body: "Coordinated advice at middle-class prices is not marketing here. It is the reason the firm exists, and it is why families drive past four competitors to reach us." },
  { title: "Room to grow fast", body: "We are expanding branches and services. Motivated people take on scope years earlier than they would at a national firm." },
  { title: "Family, not headcount", body: "Second-generation ownership, co-CEOs you will actually meet, and decisions made by people whose name is on the door." },
  { title: "Credentials supported", body: "CPA, EA, CFP® and estate designations backed with study time and reimbursement. We would rather grow specialists than rent them." },
];

export const CAREER_FITS = [
  "You would rather explain something clearly than sound impressive.",
  "You have been frustrated watching good advice go only to wealthy clients.",
  "You like owning an outcome, not passing a file down the line.",
  "You want to learn beyond your license, not stay in one lane forever.",
  "You believe a phone call answered by a human is a competitive advantage.",
];

export const ROLES = [
  { title: "Senior Tax Preparer, CPA or EA", where: "Multiple NJ branches · Full time", body: "Own a book of household returns and the planning that surrounds them, with specialists a hallway away." },
  { title: "Financial Advisor", where: "Monmouth & Ocean · Full time", body: "Retirement income and investment work for members who already trust the firm. No cold calling." },
  { title: "Estate Planning Attorney", where: "Wall Township, NJ · Full time", body: "Wills, trusts and administration for families whose tax and investment picture sits in the same room." },
  { title: "Lead Advisor", where: "NJ and NY branches · Full time", body: "Quarterback whole households, bring in the right specialist, and be the one name a family calls." },
  { title: "Client Service Associate", where: "Multiple NJ branches · Full time", body: "Be the human who answers, tracks what a family needs, and makes the experience feel personal." },
  { title: "Licensed Insurance Specialist", where: "NJ · Full time", body: "Review coverage against real obligations for members who asked for the review, not for a pitch." },
];

export const MA_POINTS = [
  "Your clients keep a familiar advisor and gain a whole team behind them.",
  "Transitions structured around your timeline, not ours.",
  "Staff retention is part of the conversation from the first meeting.",
  "Fifty years of practice integrations, handled quietly and respectfully.",
];
