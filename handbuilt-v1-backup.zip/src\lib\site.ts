export const PHONE = "1-800-TAX-LAWS®";
export const PHONE_TEL = "tel:+18008295297";
export const EMAIL = "inquiry@csicpa.com";

export const NAV = [
  { label: "Services", href: "/services" },
  { label: "360 Review", href: "/360-review" },
  { label: "Membership", href: "/membership" },
  { label: "Locations", href: "/locations" },
  { label: "Guides", href: "/guides" },
];

export const FOOTER_COMPANY = [
  { label: "About", href: "/about" },
  { label: "Membership", href: "/membership" },
  { label: "Locations", href: "/locations" },
  { label: "Guides", href: "/guides" },
  { label: "Free newsletter", href: "/guides#newsletter" },
  { label: "Join our team", href: "/join-our-team" },
  { label: "Sell your practice", href: "/sell-your-practice" },
  { label: "Member login", href: "/member-login" },
  { label: "Contact", href: "/contact" },
];

export const SERVICES = [
  { label: "Tax Preparation & Planning", href: "/services/tax" },
  { label: "Wealth Management & Financial Advisory", href: "/services/wealth" },
  { label: "Wills & Estate Planning", href: "/services/estate" },
  { label: "Insurance", href: "/services/insurance" },
  { label: "CSI360™ Financial Health Checkup", href: "/360-review" },
];

/**
 * LEGAL DISCLOSURE. Must be reproduced verbatim, never reordered or shrunk.
 * TODO (compliance): replace this placeholder with the approved disclosure covering
 * LPL Financial, CSI Group Advisors LLC, CSI Retirement Services LLC,
 * CSI Group Law Firm P.C., the separate-entity language, and that "member"
 * is descriptive only.
 */
export const LEGAL_DISCLOSURE =
  "[PLACEHOLDER: insert the approved legal disclosure from compliance before launch. It must cover LPL Financial, CSI Group Advisors LLC, CSI Retirement Services LLC, CSI Group Law Firm P.C., the separate-entity language, and that \"member\" is descriptive only.]";

export const PRINT_CODE = "PC2026-001";
